
!function($) {
    "use strict";
    var SweetAlert = function() {};
    //examples
    SweetAlert.prototype.init = function() {

    },
    //init
    $.SweetAlert = new SweetAlert, $.SweetAlert.Constructor = SweetAlert
}(window.jQuery),

//initializing
function($) {
    "use strict";
    $.SweetAlert.init()
}(window.jQuery);
