<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Konsultasi extends CI_Controller{

  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
    $this->load->view("vendor/autoload.php");
    $this->load->model("ModelChat");
    $this->load->model("ModelPasien");
    $this->load->model("ModelPegawai");
    $this->load->model("ModelKunjungan");
  }

  function Chat($norm, $no_kunjungan)
  {
    $tgl = date('Y-m-d');
    $data = array(
      'body'            => 'APO/Chat',
      'chat'            => $this->ModelChat->getKonsul($norm)->result(),
      'no_kunjungan'    => $no_kunjungan,
      'norm'            => $norm,
      'kunjungan'       => $this->ModelKunjungan->get_data($tgl),

    );
    // die(var_dump($data['kunjungan_sudah']));
		$this->load->view('APO/indexChat',$data);
  }

  public function getChat($norm, $no_kunjungan)
  {
    $chat = $this->ModelChat->getKonsul($norm);
    $data = array();
    foreach ($chat->result() as $value) {
      $ar = array(
        'text' => $value->text,
        'status' => $value->status,
        'waktui' => date("H:i:s d-m-Y", strtotime($value->waktu)),
        'nama_pasien' => $this->ModelPasien->get_data_edit($value->pasien_noRM)->row_array()["namapasien"],
        'nama_pegawai' => $this->ModelPegawai->get_data_edit($value->pegawai_NIK)["nama"],
       );
       array_push($data, $ar);
    }
    if ($chat->num_rows() > 0) {
      $data = array(
        'status'            => 1,
        'data'              => $data,
        'pesan'             => "Berhasil",
      );
      echo json_encode($data);
    }else{
      $data = array(
        'status'            => 0,
        'data'              => $chat->result(),
        'pesan'             => "Tidak Ada Chat",
      );
      echo json_encode($data);
    }

  }

  public function pesanDokter()
  {
    $data = array(
      'pegawai_NIK' => $_SESSION['nik'],
      'pasien_noRM' => $this->input->post("pasien_noRM"),
      'text'        => $this->input->post("text"),
      'waktu'        => date("Y-m-d H:i:s"),
      'status'      => "2",
      'no_kunjungan'=> $this->input->post("no_kunjungan"),
    );
    if ($this->db->insert("chat_konsul", $data)) {
      $this->db->where("pasien_noRM", $this->input->post("pasien_noRM"));
      $this->db->update("chat_konsul", array('status_baca' => "0"));
          $options = array(
            'cluster' => 'ap1',
            'useTLS' => true
          );
          $pusher = new Pusher\Pusher(
            '4f343bacaa7b3063150d',
            '8b7ea5bf2355c1b85330',
            '975255',
            $options
          );
          $data["jam"] = date("H:i:s");
          $data["tgl"] = date("d-m-Y");
          $data["waktui"] = date("H:i:s d-m-Y");
          $data["nama_pegawai"] = $this->ModelPegawai->get_data_edit($_SESSION['nik'])["nama"];
          $data["nama_pasien"] = $this->ModelPasien->get_data_edit($this->input->post("pasien_noRM"))->row_array()["namapasien"];
          $pusher->trigger('my-Pasien', $this->input->post("pasien_noRM"), $data);
          echo json_encode($data);
        }else {
          echo "0";
        }
  }

  public function pesanPasien()
  {
    $data = array(
      'pegawai_NIK' => "0",
      'pasien_noRM' => $this->input->post("pasien_noRM"),
      'text'        => $this->input->post("text"),
      'waktu'        => date("Y-m-d H:i:s"),
      'status'      => "1",
      'no_kunjungan'=> $this->input->post("no_kunjungan"),
    );
    if ($this->db->insert("chat_konsul", $data)) {
      $options = array(
        'cluster' => 'ap1',
        'useTLS' => true
      );
      $pusher = new Pusher\Pusher(
        '4f343bacaa7b3063150d',
        '8b7ea5bf2355c1b85330',
        '975255',
        $options
      );
      $data["jam"] = date("H:i:s");
      $data["tgl"] = date("d-m-Y");
      $data["waktui"] = date("H:i:s d-m-Y");
      $data["nama_pasien"] = $this->ModelPasien->get_data_edit($this->input->post("pasien_noRM"))->row_array()["namapasien"];
      $pusher->trigger('E-klinik', "my-konsul", $data);
      echo json_encode($data);
    }else {
      echo "0";
    }
  }

}
