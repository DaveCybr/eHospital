<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class JadwalOperasi extends CI_Controller{

  public function __construct()
  {
    parent::__construct();
    //Codeigniter : Write Less Do More
    $this->load->model("ModelJadwalOperasi");
    $this->load->model("ModelPegawai");
  }

  function index()
  {
    $data = array(
      'body'  =>  'JadwalOperasi/list',
      'JadwalOperasi'   =>  $this->ModelJadwalOperasi->get_data()->result(),
    );
    $this->load->view('index', $data);
  }

  function input()
  {
    $data = array(
      'form'  =>  'JadwalOperasi/form',
      'body'  =>  'JadwalOperasi/input',
      'pegawai' =>  $this->ModelPegawai->get_dokter(),
    );
    $this->load->view('index', $data);
  }

  function insert()
  {
    $data = array(
      'tanggal' =>  $this->input->post("tanggal"),
      'jam' =>  $this->input->post("jam"),
      'pegawai_NIK' =>  $this->input->post("nama_dokter"),
    );
    if ($this->db->insert('jadwal_operasi', $data)) {
      $this->session->set_flashdata('notifJS', array('heading' => "Berhasil",'text'=>"Tambah Jadwal Operasi Berhasil","type" => "success" ));
      redirect(base_url().'JadwalOperasi');
    } else {
      $this->session->set_flashdata('notifJS', array('heading' => "Gagal",'text'=>"Mohon Untuk Melakukan Tambah Ulang","type" => "danger" ));
      redirect(base_url().'JadwalOperasi/input');
    }
  }

  function edit ($id)
  {
    $data = array(
      'form'  =>  'JadwalOperasi/form',
      'body'  =>  'JadwalOperasi/edit',
      'JadwalOperasi'   => $this->ModelJadwalOperasi->get_edit_data($id)->row_array()
    );
    $this->load->view('index', $data);
  }

  function update()
  {
    $data = array(
      'tanggal' =>  $this->input->post("tanggal"),
      'jam'     =>  $this->input->post("jam"),
    );
    $this->db->where("idjadwal_operasi", $this->input->post("idjadwal_operasi"));
    if ($this->db->update('jadwal_operasi', $data)) {
      $this->session->set_flashdata('notifJS', array('heading' => "Berhasil",'text'=>"Edit Jadwal Operasi Berhasil","type" => "success" ));
      redirect(base_url().'JadwalOperasi');
    } else {
      $this->session->set_flashdata('notifJS', array('heading' => "Gagal",'text'=>"Mohon Untuk Melakukan Edit Ulang","type" => "danger" ));
      redirect(base_url().'JadwalOperasi');
    }
  }

  function hapus()
  {
    $id=$this->uri->segment(3);
    $this->db->where("idjadwal_operasi", $id);
    if ($this->db->delete('jadwal_operasi')) {
      $this->session->set_flashdata('notifJS', array('heading' => "Berhasil",'text'=>"Hapus Jadwal Operasi Berhasil","type" => "success" ));
      redirect(base_url().'JadwalOperasi');
    } else {
      $this->session->set_flashdata('notifJS', array('heading' => "Gagal",'text'=>"Mohon Untuk Melakukan Hapus Ulang","type" => "danger" ));
      redirect(base_url().'JadwalOperasi');
    }
  }

}
