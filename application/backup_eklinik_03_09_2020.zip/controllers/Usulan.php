<?php
  defined('BASEPATH') OR exit('No direct script access allowed');

  class Usulan extends CI_Controller{

    public function __construct()
    {
      parent::__construct();
      $this->load->helper(array('url', 'language'));
      $this->load->model('ModelPembelianObat');
      $this->load->model('ModelPerencanaan');
      $this->load->model('ModelSupplier');
      $this->load->model('ModelObat');
      $this->load->model('ModelAkuntansi');
    }

    function index()
    {
      $data = array(
        'body' => 'Usulan/list',
        'perencanaan' => $this->ModelPerencanaan->get_data_usulan(),
        'form_dialog' => 'PerencanaanObat/form_dialog2',
       );
      $this->load->view('index', $data);
    }

    function input($id="")
    {
      $perencanaan = $this->db
      ->join("supplier","supplier.kode_sup=perencanaan_obat.supplier_kode_sup")
      ->where("idperencanaan",$id)->get("perencanaan_obat")->row();
      $detail_obat = $this->db
      ->join("obat","obat.idobat=detail_perencanaan.obat_idobat")
      ->where("perencanaan_obat_idperencanaan",$id)->get("detail_perencanaan")->result();
      $data = array(
        'form' => 'Usulan/form',
        'form_dialog' => 'Usulan/form_dialog',
        'body' => 'Usulan/input',
        'supplier' => $this->ModelSupplier->get_data(),
        'obat' => $this->ModelObat->get_data(),
        'perencanaan' =>$perencanaan,
        'detail_obat' =>$detail_obat
       );
      $this->load->view('index', $data);
    }

    public function insert($id="")
    {

      $pengajuan_obat = array(
        'supplier_kode_sup' => $this->input->post('supplier'),
        'tanggal' => date("Y-m-d"),
        'NIK' => $_SESSION['nik'],
        // 'status_usu' => 0,
        'idperencanaan' =>$id
      );

      $this->db->where("idperencanaan",$id)->update("perencanaan_obat",array("input_usulan"=>1));

      if ($this->db->insert('pengajuan_obat', $pengajuan_obat)) {
        $id_obat = $this->input->post('id_obat');
        $jumlah = $this->input->post("jumlah");
        $id_detail = $this->input->post("id_detail");
        $id_pengajuan = $this->db->insert_id();
        $count = count($id_obat);
        for($i=0;$i<$count;$i++){
           $detail_pengajuan_obat = array(
            'obat_idobat' => $id_obat[$i],
            'jumlah_pengajuan' => $jumlah[$i],
            'pengajuan_obat_idpengajuan_obat' => $id_pengajuan,
            'iddetail_perencanaan' =>$id_detail[$i],
          );
          $this->db->insert('detail_pengajuan', $detail_pengajuan_obat);

        }
        $this->session->set_flashdata('notif', $this->Notif->berhasil('Usulan Jumlah Obat Berhasil Disimpan!!!!'));
        redirect(base_url().'Usulan');
      }
    }

    public function hapus_detail()
    {
      $id = $this->input->post('id');
      $data = $this->db->where('iddetail_pembelian_obat',$id)->get('detail_pembelian_obat')->row_array();
      $id_obat = $data['obat_idobat'];
      $data_obat = $this->ModelObat->get_data_edit($id_obat)->row_array();
      $stok = $data_obat['stok']-$data['jumlah_satuan_kecil'];
      $stok_berjalan = $data_obat['stok_berjalan']-$data['jumlah_satuan_kecil'];
      $update_stok = array(
        'stok'=>$stok,
        'stok_berjalan'=>$stok_berjalan
      );
      $this->db->where('idobat', $id_obat);
      $this->db->update('obat',$update_stok);
      $this->db->where_in('iddetail_pembelian_obat', $id);
      $delete = $this->db->delete('detail_pembelian_obat');
      if ($delete) {
        $res = array(
          'success' => true
        );
      } else {
        $res = array(
          'success' => false
        );
      }
      echo json_encode($res);
    }
    public function get_detail(){
      $no_nota = $this->input->post('no_nota');
      $data_detail = $this->ModelPembelianObat->get_detail_nota($no_nota);

      echo json_encode($data_detail);
    }

    public function cek_status_hutang($t_bayar,$sisa){
      if($t_bayar<=0){
        $data = array(
          'sisa' => $sisa,
          'status' => 'hutang'
        );
      }else{
        if ($sisa>0) {
          $data = array(
            'sisa' => $sisa,
            'status' => 'belum lunas'
          );
        }else{
          $data = array(
            'sisa' => $sisa,
            'status' => 'lunas'
          );
        }
      }
      return $data;
    }

    public function edit($no_nota=null){
      $data = array(
        'form' => 'PembelianObat/form_edit',
        'form_dialog' => 'PembelianObat/form_dialog',
        'body' => 'PembelianObat/edit',
        'nota' => $this->ModelPembelianObat->get_data_edit($no_nota)->row_array(),
        'detail_nota' => $this->ModelPembelianObat->get_detail($no_nota),
        'supplier' => $this->ModelSupplier->get_data(),
        'obat' => $this->ModelObat->get_data()
       );
      $this->load->view('index', $data);
    }

    public function update($no_nota)
    {
      $sisa = $this->input->post('sisa');
      $jatuh_tempo = date("Y-m-d",strtotime($this->input->post("jatuh_tempo")));
      if($sisa>0){
        $status ="Belum Lunas";
      }else{
        $status ="Lunas";
      }
      $detil = $this->db->where_in('pembelian_obat_no_nota',$no_nota)->get('detail_pembelian_obat')->result();
      foreach ($detil as $value) {
        if ($value->jumlah_terjual==null) {
          $terjual = 0;
        }else{
          $terjual = $value->jumlah_terjual;
        }
        $jumlah = (int)$value->jumlah_satuan_kecil-(int)$terjual;
        $data_obat = $this->db->get_where('obat',array('idobat'=>$value->obat_idobat))->row_array();
        $stok = (int)$data_obat['stok']-$jumlah;
        $stok_berjalan = (int)$data_obat['stok_berjalan']-$jumlah;
        $this->db->where('idobat',$data_obat['idobat']);
        $this->db->update('obat',array('stok'=>$stok,'stok_berjalan'=>$stok_berjalan));

      }
      $this->db->where_in('pembelian_obat_no_nota',$no_nota);
      $this->db->delete('detail_pembelian_obat');
      $pembelian_obat = array(
        'no_nota_supplier' => $this->input->post('no_nota_supplier'),
        'supplier_kode_sup' => $this->input->post('supplier'),
        'tanggal_masuk' => date("Y-m-d",strtotime($this->input->post('tanggal_masuk'))),
        'total_bayar' => $this->input->post('bayar'),
        'total_transaksi'=> $this->input->post("tot_harga"),
        'total_ppn' => $this->input->post("tot_ppn"),
        'total_diskon' => $this->input->post("tot_diskon"),
        'total_bayar' => $this->input->post("bayar_final"),
        'bayar' => $this->input->post("bayar"),
        'sisa' => $sisa,
        'status' => $status
      );
      $this->db->where('no_nota',$no_nota);
      if ($this->db->update('pembelian_obat', $pembelian_obat)) {
        $id_obat = $this->input->post('id_obat');
        $no_batch = $this->input->post('no_batch');
        $jumlah = $this->input->post('jumlah');
        $hrg_beli = $this->input->post('harga_beli');
        $diskon = $this->input->post('diskon');
        $tanggal_expired = $this->input->post('ed');
        $ppn = $this->input->post('ppn');
        $ttl_harga = $this->input->post('ttl_harga');
        $count = count($id_obat);
        $total_harga=0;$total_diskon=0;$total_ppn=0;
        $satuan = $this->input->post("satuan");
        $satuan_beli = $this->input->post('satuan_beli');
        for($i=0;$i<$count;$i++){
          //menghitung harga persatuan
          $data_obat = $this->ModelObat->get_data_edit($id_obat[$i])->row_array();
          $satuan_besar;$satuan_sedang;$satuan_kecil;$jml_satuan_kecil;$hrg_beli_satuan_kecil;$hrg_beli;$stok;$stok_berjalan;
          $satuan_besar = $data_obat['jml_satuan_besar'];
          $satuan_sedang = $data_obat['jml_satuan_sedang'];
          $satuan_kecil = $data_obat['jml_satuan_kecil'];
          if ($satuan[$i]==$data_obat['satuan_besar']) {
            $jml_satuan_kecil =  (int)$jumlah[$i]*(int)$satuan_besar*(int)$satuan_sedang*(int)$satuan_kecil;
          }
          else if ($satuan[$i]==$data_obat['satuan_sedang']) {
            $jml_satuan_kecil =  (int)$jumlah[$i]*(int)$satuan_sedang*(int)$satuan_kecil;
          }
          else{
            $jml_satuan_kecil =  (int)$jumlah[$i]*(int)$satuan_kecil;
          }
          $hrg_beli_satuan_kecil = (int) ($ttl_harga[$i]/$jml_satuan_kecil);
          $stok = $jml_satuan_kecil+$data_obat['stok'];
          $stok_berjalan = $jml_satuan_kecil+$data_obat['stok_berjalan'];
          $detail_pembelian_obat = array(
            'no_batch' => $no_batch[$i],
            'jumlah' => $jumlah[$i],
            'jumlah_satuan_kecil' => $jml_satuan_kecil,
            'hrg_beli' => $hrg_beli[$i],
            'hrg_beli_satuan_kecil' => $hrg_beli_satuan_kecil,
            'diskon' => $diskon[$i],
            'tanggal_expired' => $tanggal_expired[$i],
            'pembelian_obat_no_nota' => $no_nota,
            'obat_idobat' => $id_obat[$i],
            'ppn' => $ppn[$i],
            'total_harga' => $ttl_harga[$i],
            'satuan_beli' => $satuan[$i]
          );
          $this->db->insert('detail_pembelian_obat', $detail_pembelian_obat);
          $update = array(
            'harga_beli_satuan_kecil' => $hrg_beli_satuan_kecil,
            'harga_beli_satuan_sedang' => (int)$hrg_beli_satuan_kecil*$satuan_sedang,
            'harga_beli_satuan_besar' => (int)$hrg_beli_satuan_kecil*$satuan_sedang*$satuan_besar,
            'stok' => $stok,
            'stok_berjalan' => $stok_berjalan
          );
          $this->db->where('idobat',$id_obat[$i]);
          $this->db->update('obat',$update);
        }
        $this->db->where('pembelian_obat_no_nota',$no_nota)->update('hutang', array('tanggal'=>date("Y-m-d"),'total_hutang'=>$sisa,'tanggal_jatuh_tempo'=>$jatuh_tempo));
        $this->session->set_flashdata('notif', $this->Notif->berhasil('Nota Pembelian Berhasil Disimpan!!!!'));
        redirect(base_url().'PembelianObat');
      }

    }

    public function delete()
    {
      $no_nota = $this->input->post('id');
      $this->db->where_in('pembelian_obat_no_nota',$no_nota);
      $this->db->delete('hutang');
      $detil = $this->db->where_in('pembelian_obat_no_nota',$no_nota)->get('detail_pembelian_obat')->result();
      foreach ($detil as $value) {
        if ($value->jumlah_terjual==null) {
          $terjual = 0;
        }else{
          $terjual = $value->jumlah_terjual;
        }
        $jumlah = (int)$value->jumlah_satuan_kecil-(int)$terjual;
        $data_obat = $this->db->get_where('obat',array('idobat'=>$value->obat_idobat))->row_array();
        $stok = (int)$data_obat['stok']-$jumlah;
        $stok_berjalan = (int)$data_obat['stok_berjalan']-$jumlah;
        $this->db->where('idobat',$data_obat['idobat']);
        $this->db->update('obat',array('stok'=>$stok,'stok_berjalan'=>$stok_berjalan));

      }
      $this->db->where_in('pembelian_obat_no_nota',$no_nota);
      $delete_detail = $this->db->delete('detail_pembelian_obat');
      if ($delete_detail) {
        $this->db->where_in('no_nota', $no_nota);
        $delete = $this->db->delete('pembelian_obat');
        if ($delete) {
            $this->session->set_flashdata('notif', $this->Notif->berhasil('Berhasil Hapus Data Pembelian Obat'));
        }else{
            $this->session->set_flashdata('notif', $this->Notif->berhasil('Gagal Hapus Data Pembelian Obat'));
        };

      }else{
          $this->session->set_flashdata('notif', $this->Notif->gagal('Gagal Hapus Data!!!!'));
      }
      redirect(base_url().'PembelianObat');
    }

    public function get_obat(){
      $data_obat = $this->ModelObat->get_data_edit($this->input->post('id_obat'))->row_array();
      echo json_encode($data_obat);
    }

    public function get_satuan(){
      $id_obat = $this->input->post('id_obat');
      $data_obat = $this->ModelObat->get_data_edit($id_obat)->row_array();
      $data_satuan = array();
      if($data_obat!=null){
        array_push($data_satuan,array(
          'label' => 'satuan_besar',
          'satuan' => $data_obat['satuan_besar'],
          'harga_satuan' => $data_obat['harga_beli_satuan_besar'],
          'jml_satuan' => $data_obat['jml_satuan_besar']
        ));
        array_push($data_satuan,array(
          'label' => 'satuan_sedang',
          'satuan' => $data_obat['satuan_sedang'],
          'harga_satuan' => $data_obat['harga_beli_satuan_sedang'],
          'jml_satuan' => $data_obat['jml_satuan_sedang']
        ));
        array_push($data_satuan,array(
          'label' => 'satuan_kecil',
          'satuan' => $data_obat['satuan_kecil'],
          'harga_satuan' => $data_obat['harga_beli_satuan_kecil'],
          'jml_satuan' => $data_obat['jml_satuan_kecil']
        ));

      }
      echo json_encode($data_satuan);
    }

    public function persetujuan($id=""){
      $perencanaan = $this->db
      ->join("supplier","supplier.kode_sup=pengajuan_obat.supplier_kode_sup")
      ->where("idpengajuan_obat",$id)->get("pengajuan_obat")->row();
      $detail_obat = $this->db
      ->join("obat","obat.idobat=detail_pengajuan.obat_idobat")
      ->where("pengajuan_obat_idpengajuan_obat",$id)->get("detail_pengajuan")->result();
      $data = array(
        'form' => 'Usulan/form_persetujuan',
        'form_dialog' => 'Usulan/form_dialog',
        'body' => 'Usulan/input_persetujuan',
        'supplier' => $this->ModelSupplier->get_data(),
        'obat' => $this->ModelObat->get_data(),
        'perencanaan' =>$perencanaan,
        'detail_obat' =>$detail_obat
       );
      $this->load->view('index', $data);
    }

    public function koreksi($id=""){
      $perencanaan = $this->db
      ->join("supplier","supplier.kode_sup=pengajuan_obat.supplier_kode_sup")
      ->where("idpengajuan_obat",$id)->get("pengajuan_obat")->row();
      $detail_obat = $this->db
      ->join("obat","obat.idobat=detail_pengajuan.obat_idobat")
      ->where("pengajuan_obat_idpengajuan_obat",$id)->get("detail_pengajuan")->result();
      $data = array(
        'form' => 'Usulan/form_persetujuan',
        'form_dialog' => 'Usulan/form_dialog',
        'body' => 'Usulan/input_persetujuan',
        'supplier' => $this->ModelSupplier->get_data(),
        'obat' => $this->ModelObat->get_data(),
        'perencanaan' =>$perencanaan,
        'detail_obat' =>$detail_obat
       );
      $this->load->view('index', $data);
    }

    public function setujui_usulan($id=""){
      $pengajuan_obat = array(
        'status_usulan' => 1
      );

      if ($this->db->where("idpengajuan_obat",$id)->update('pengajuan_obat', $pengajuan_obat)) {
        $usulan = $this->db->where("idpengajuan_obat",$id)->get('pengajuan_obat')->row_array();
        $this->db->where("idperencanaan",$usulan['idperencanaan'])->update("perencanaan_obat",$pengajuan_obat);
        $id_obat = $this->input->post('id_obat');
        $id_detail = $this->input->post("id_detail");
        $jumlah = $this->input->post("jumlah");
        $count = count($id_obat);
        for($i=0;$i<$count;$i++){
           $detail_pengajuan_obat = array(
            'jumlah_disetujui' => $jumlah[$i],
          );
          $this->db->where("iddetail_pengajuan",$id_detail[$i])->update('detail_pengajuan', $detail_pengajuan_obat);

        }
        $this->session->set_flashdata('notif', $this->Notif->berhasil('Berhasil Disimpan!!!'));
        redirect(base_url().'Usulan');
      }
    }


    public function input_penerimaan($id=""){
      $no_nota = $this->ModelPembelianObat->generate_no_nota();
      $sisa = $this->input->post('sisa');
      $jatuh_tempo = date("Y-m-d",strtotime($this->input->post("jatuh_tempo")));
      if($sisa<0){
        $status ="Belum Lunas";
      }else{
        $status ="Lunas";
        $sisa = 0;
      }
      $pembelian_obat = array(
        'no_nota' => $no_nota,
        'no_nota_supplier' => $this->input->post('no_nota_supplier'),
        'supplier_kode_sup' => $this->input->post('supplier'),
        'tanggal_masuk' => date("Y-m-d",strtotime($this->input->post('tanggal_masuk'))),
        // 'total_bayar' => $this->input->post('bayar'),
        'total_transaksi'=> $this->input->post("tot_harga"),
        'total_ppn' => $this->input->post("tot_ppn"),
        'total_diskon' => $this->input->post("tot_diskon"),
        'total_bayar' => $this->input->post("bayar_final"),
        'bayar' => $this->Core->combine_harga($this->input->post("bayar")),
        'sisa' => $sisa,
        'status' => $status
      );
      $jam = date("H:i:s");
      $kode = $no_nota;
      $kode_akun = $this->ModelAkuntansi->generete_notrans();
      if ($sisa<0) {
        $jurnal = array(
          'tanggal' => date("Y-m-d"),
          'keterangan' => 'Transaksi pembelian obat dengan nomor transaksi '.$pembelian_obat['no_nota'].' pada tanggal '.date("d-m-Y"),
          'norek' => '116.001',
          'debet' => 0,
          'kredit' =>  $pembelian_obat['total_bayar'],
          'no_transaksi' => $kode_akun,
          'jam' => $jam
        );
        $this->db->insert('jurnal',$jurnal);
      if ($pembelian_obat['bayar'] > 0) {
          $jurnal_kas = array(
            'tanggal' => date("Y-m-d"),
            'keterangan' => 'Transaksi pembelian obat dengan nomor transaksi '.$pembelian_obat['no_nota'].' pada tanggal '.date("d-m-Y"),
            'norek' => '111.001',
            'debet' =>  $pembelian_obat['bayar'],
            'kredit' => 0,
            'no_transaksi' => $kode_akun,
            'jam' => $jam
          );
          $this->db->insert('jurnal',$jurnal_kas);
        }
        $jurnal1 = array(
          'tanggal' => date("Y-m-d"),
          'keterangan' => 'Transaksi pembelian obat dengan nomor transaksi '.$pembelian_obat['no_nota'].' pada tanggal '.date("d-m-Y"),
          'norek' => '211.001',
          'debet' => 0,
          'kredit' => $pembelian_obat['total_bayar']-$pembelian_obat['bayar'],
          'no_transaksi' => $kode_akun,
          'jam' => $jam
        );
        $this->db->insert('jurnal',$jurnal1);
      }else{
        $jurnal1 = array(
          'tanggal' => date("Y-m-d"),
          'keterangan' => 'Transaksi pembelian obat dengan nomor transaksi '.$pembelian_obat['no_nota'].' pada tanggal '.date("d-m-Y"),
          'norek' => '111.001',
          'debet' => 0,
          'kredit' => $pembelian_obat['total_bayar'],
          'no_transaksi' => $kode_akun,
          'jam' => $jam
        );
        $jurnal = array(
          'tanggal' => date("Y-m-d"),
          'keterangan' => 'Transaksi pembelian obat dengan nomor transaksi '.$pembelian_obat['no_nota'].' pada tanggal '.date("d-m-Y"),
          'norek' => '116.001',
          'debet' => $pembelian_obat['total_bayar'],
          'kredit' => 0,
          'no_transaksi' => $kode_akun,
          'jam' => $jam
        );
        $this->db->insert('jurnal',$jurnal);
        $this->db->insert('jurnal',$jurnal1);
      }
      // $this->db->insert("jurnal",$jurnal);
      // $this->db->insert("jurnal",$jurnal1);
      if ($this->db->insert('pembelian_obat', $pembelian_obat)) {
        $pengajuan_obat = array(
          'status_pesanan' => 1,
          'jatuh_tempo' => date("Y-m-d",strtotime($this->input->post("jatuh_tempo"))),
          'total' => $this->input->post("tot_harga"),
          'tanggal_masuk' => date("Y-m-d",strtotime($this->input->post("tanggal_masuk"))),
          'NIK_penerima' => $_SESSION['nik'],
          'no_nota' => $no_nota

        );

        if ($this->db->where("idpengajuan_obat",$id)->update('pengajuan_obat', $pengajuan_obat)) {
          $id_obat = $this->input->post('id_obat');
          $id_detail = $this->input->post("id_detail");
          $jumlah = $this->input->post("jumlah");
          $ppn = $this->input->post("ppn");
          $diskon = $this->input->post("diskon");
          $satuan = $this->input->post("satuan");
          $harga_beli = $this->input->post("harga_beli");
          $total_harga = $this->input->post("total_harga");
          $ed = $this->input->post("ed");
          $count = count($id_obat);
          for($i=0;$i<$count;$i++){
             $detail_pengajuan_obat = array(
              'tanggal_kadaluarsa' =>$ed[$i],
              'status_mutasi' => 0,
              'satuan' => $satuan[$i],
              'jumlah_masuk' => $jumlah[$i],
              'harga_beli' => $harga_beli[$i],
              'total_harga' =>  $jumlah[$i]*$harga_beli[$i],
              'diskon' => $diskon[$i],
              'ppn' => $ppn[$i]
            );
            $this->db->where("iddetail_pengajuan",$id_detail[$i])->update('detail_pengajuan', $detail_pengajuan_obat);
            $data_usulan = $this->db
            ->select("sum(harga_beli) as harga,count(*) as jumlah")
            ->get_where("detail_pengajuan",array("harga_beli !="=>NULL,"obat_idobat"=>$id_obat[$i]))->row();
            if ($data_usulan->harga > 0 && $data_usulan->jumlah>0) {
              $harga_beli = round($data_usulan->harga/$data_usulan->jumlah);
              $harga_jual = round($harga_beli*1.55);
                $this->db->where("idobat",$id_obat[$i])->update('obat', array(
                  "harga_1" => $harga_jual,
                  "harga_2" => $harga_jual,
                  "harga_3" => $harga_jual,
                  'harga_beli_satuan_kecil' => $harga_beli,
                  'harga_beli_satuan_sedang' => $harga_beli,
                  'harga_beli_satuan_besar' => $harga_beli,


                ));

            }


          }
        }
        $this->db->insert('hutang', array('tanggal'=>date("Y-m-d"),'total_hutang'=>abs($sisa),'pembelian_obat_no_nota'=>$no_nota,'tanggal_jatuh_tempo'=>$jatuh_tempo));

        $this->session->set_flashdata('notif', $this->Notif->berhasil('Berhasil Disimpan!!!'));
        redirect(base_url().'Usulan');
      }






    }

    public function mutasi_gudang($id=''){
      $data = $this->db->get_where("detail_pengajuan",array('pengajuan_obat_idpengajuan_obat'=>$id))->result();
      foreach ($data as $value) {
        $data = array(
          'obat_idobat' => $value->obat_idobat,
          'ed' => $value->tanggal_kadaluarsa,
          'jumlah_stok' => $value->jumlah_masuk,
          'iddetail_pengajuan' => $value->iddetail_pengajuan
        );
        $this->db->insert("gudang_obat",$data);
      }
      $this->db->where("idpengajuan_obat",$id)->update("pengajuan_obat",array("status_mutasi"=>1));
      redirect(base_url().'Usulan');
    }

    public function terima_barang($id=''){
      $usulan = $this->db
      ->join("supplier","supplier.kode_sup=pengajuan_obat.supplier_kode_sup")
      ->where("idpengajuan_obat",$id)->get("pengajuan_obat")->row();
      $detail_obat = $this->db
      ->join("obat","obat.idobat=detail_pengajuan.obat_idobat")
      ->where("pengajuan_obat_idpengajuan_obat",$id)
      ->where("jumlah_disetujui !=",0)
      ->get("detail_pengajuan")->result();
      $data = array(
        'form' => 'Usulan/form_terima_barang',
        'form_dialog' => 'Usulan/form_dialog',
        'body' => 'Usulan/terima_barang',
        'supplier' => $this->ModelSupplier->get_data(),
        'obat' => $this->ModelObat->get_data(),
        'usulan' =>$usulan,
        'detail_obat' =>$detail_obat
       );
      $this->load->view('index', $data);
    }

    public function cetak($id=""){
      $user = $this->db
      ->select("pegawai.*")
      ->join("pegawai","pegawai.NIK=pengajuan_obat.NIK")
      ->get_where("pengajuan_obat",array("idpengajuan_obat"=>$id))->row();
      $supplier = $this->db
      ->join("supplier","supplier.kode_sup=pengajuan_obat.supplier_kode_sup")
      ->where("idpengajuan_obat",$id)->get("pengajuan_obat")->row();
      $detail = $this->db
      ->join("obat","obat.idobat=detail_pengajuan.obat_idobat")
      ->get_where("detail_pengajuan",array("pengajuan_obat_idpengajuan_obat"=>$id))->result();
      $data = array(
        'user' => $user,
        'detail' =>$detail,
        'supplier' => $supplier
      );

      $this->load->view("Usulan/cetak_pengadaan",$data);
    }

    public function cetak_penerimaan($id=""){
      $user = $this->db
      ->select("pegawai.*")
      ->join("pegawai","pegawai.NIK=pengajuan_obat.NIK_penerima")
      ->get_where("pengajuan_obat",array("idpengajuan_obat"=>$id))->row();
      $supplier = $this->db
      ->join("supplier","supplier.kode_sup=pengajuan_obat.supplier_kode_sup")
      ->where("idpengajuan_obat",$id)->get("pengajuan_obat")->row();
      $detail = $this->db
      ->join("obat","obat.idobat=detail_pengajuan.obat_idobat")
      ->get_where("detail_pengajuan",array("pengajuan_obat_idpengajuan_obat"=>$id))->result();
      $data = array(
        'user' => $user,
        'detail' =>$detail,
        'supplier' => $supplier
      );

      $this->load->view("Usulan/cetak_penerimaan",$data);
    }

  }
?>
