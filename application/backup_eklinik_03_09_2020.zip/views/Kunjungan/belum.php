<div class="row">
  <!-- <div class="col-12"> -->
    <div class="card card-cascade narrower z-depth-1">
      <div class="view view-cascade gradient-card-header purple-gradient narrower py-2 mx-4 mb-3 d-flex justify-content-between align-items-center">
        <a href="" class="white-text mx-3">Daftar Tunggu Pasien (Pasien Belum Di Periksa)</a>
      </div>
      <div class="card-body">
        <div class="table-responsive" id="kunjungan_belum">
          <table id="example_blm" class="table table-bordered table-striped table-hover">
            <thead>
              <tr>
                <th width="1%">#</th>

                <th width="1%">No Urut Pcare</th>
                <th>Pasien</th>
                <th>Keluhan</th>
                <th>BPJS</th>
                <th>No Asuransi lain</th>
                <th>Umur</th>
                <th>Tujuan</th>
                <!-- <th>Antrian</th> -->
                <th>Jam</th>
                <th>Jenis</th>
                <th>Opsi</th>
              </tr>
            </thead>
            <tbody id="tabel_belum_periksa" >
              <?php $no=1;foreach ($kunjungan as $value): ?>
                <?php $id_check = $value->no_urutkunjungan;$warna = "badge-primary";?>
                <tr id="kunjungan_<?php echo $value->pasien_noRM?>">
                    <!-- <td><?php echo $no;?></td> -->
                  <td><?php echo $value->kd_antrian."".$value->no_antrian;?></td>
                <td><?php echo $value->nourut_pcare;?></td>
                  <!-- <td class="no_kunjungan_hari_ini"><?php echo $no;?></td> -->
                  <td><?php echo $value->namapasien ?></td>
                  <td>
                    <?php echo $value->keluhan ?>
                    <?php $skrinning = $this->db->get_where("skrinning",array('idskrinning' => $value->skrinning_idskrinning));?>
                    <?php if ($skrinning->num_rows() > 0): ?>
                      <span class="badge badge-pill peach-gradient"><?php echo $skrinning->row_array()["status"]?></span>
                    <?php endif; ?>
                  </td>
                  <td><?php echo $value->noBPJS ?></td>
                  <td><?php echo $value->noAsuransiLain ?></td>
                  <td><?php echo $this->Core->umur($value->tgl_lahir) ?></td>
                  <td><?php $k = $value->kode_tupel;
                  $type = "IN";
                  if ($k == "UMU"){$warna = "badge-success"; $type="U";}elseif ($k == "IGD") {$warna = "badge-danger";$type="IG";}elseif($k == "OBG"){$warna = "badge-info";$type="O";}
                  elseif ($k == "GIG") {$warna = "badge-warning";$type="G";}elseif ($k == "OZO") {$warna = "badge-info";$type="OZ";} ?>
                  <h4><span class="badge badge-pill <?php echo $warna; ?>"><?php echo $value->tujuan_pelayanan;?></span></h4>
                  <?php if ($value->status_online == 1): ?><h5><span class="badge badge-pill blue-gradient">Pendaftar Online</span></h5>
                    <?php
                    $baru = $this->ModelChat->getChatBaca($value->pasien_noRM, 1)->num_rows();
                    if ($baru > 0) { ?>
                      <h5><span class="badge badge-pill peach-gradient">Pesan Baru <?php echo $baru ?></span></h5>
                    <?php }
                     ?>
                  <?php endif; ?>
                  <?php if ($value->status_online == 2): ?><h5><span class="badge badge-pill blue-gradient">Pendaftar Mandiri</span></h5><?php endif; ?>

                  </td>
                  <td><?php echo $value->jam_daftar;?></td>
                  <td><?php echo $value->sumber_dana==7?"<h4><span class='badge badge-pill badge-success'>".$value->jenis_pasien."</h4>":"<h4><span class='badge badge-pill badge-danger'>".$value->jenis_pasien."</h4>"?></td>
                  <td>
                    <a href="<?php echo $value->status_deposit==0 && $k!="IGD"?"#":base_url()."Periksa/index/".$value->no_urutkunjungan; ?>">
                      <button data-toggle="tooltip" data-placement="top" title="" data-original-title="Periksa" <?php echo $value->status_deposit==0 && $k!="IGD"?'disabled':''?> type="button" class="btn btn-primary periksa btn-sm">
                        <i class="fa fa-stethoscope"></i>
                      </button>
                    </a>
                    <?php if ($value->status_online == 1): ?>
                      <a href="<?php echo $value->status_deposit==0 && $k!="IGD"?"#":base_url()."APO/Konsultasi/Chat/".$value->pasien_noRM."/".$value->no_urutkunjungan; ?>" target="new">
                        <button data-toggle="tooltip" data-placement="top" title="" data-original-title="Chat Pasien" <?php echo $value->status_deposit==0 && $k!="IGD"?'disabled':''?> type="button" class="btn btn-info btn-sm">
                          <i class="fas fa-comments"></i>
                        </button>
                      </a>
                    <?php endif; ?>

                    <?php if ($k == "GIG"): ?>
                        <a href="#">
                          <button data-toggle="tooltip" data-placement="top" title="" data-original-title="Panggil" type="button" class="btn btn-success periksa btn-sm panggilan_pasien" antrian="<?php echo $_SESSION['poli']."-".$value->no_antrian."-".$id_check."-".$value->namapasien;?>">
                            <i class="fa fa-volume-up"></i>
                          </button>
                        </a>
                      <?php else: ?>
                        <?php if ($value->poli_panggil == "UMU"){ ?>
                          <a href="#">
                            <button data-toggle="tooltip" id="UMU-<?php echo $value->no_urutkunjungan?>" data-placement="top" title="" data-original-title="Panggil Poli Umum 1" type="button" class="btn btn-success periksa btn-sm panggilan_pasien hilang-UMU2-<?php echo $id_check ?>" antrian="<?php echo $_SESSION['poli']."-".$value->no_antrian."-".$id_check."-".$value->namapasien;?>">
                              <i class="fa fa-volume-up"></i>
                            </button>
                          </a>
                        <?php }elseif ($value->poli_panggil == "UMU2"){ ?>
                          <a href="#">
                            <button data-toggle="tooltip" id="UMU-<?php echo $value->no_urutkunjungan?>" data-placement="top" title="" data-original-title="Panggil Poli Umum 1" type="button" class="btn btn-success periksa btn-sm panggilan_pasien hilang-UMU-<?php echo $id_check ?>" antrian="<?php echo $_SESSION['poli']."2-".$value->no_antrian."-".$id_check."-".$value->namapasien;?>">
                              <i class="fa fa-volume-up"></i>
                            </button>
                          </a>
                        <? }else{?>
                        <a href="#">
                          <button data-toggle="tooltip" id="UMU-<?php echo $value->no_urutkunjungan?>" data-placement="top" title="" data-original-title="Panggil Poli Umum 1" type="button" class="btn btn-success periksa btn-sm panggilan_pasien hilang-UMU2-<?php echo $id_check ?>" antrian="<?php echo $_SESSION['poli']."-".$value->no_antrian."-".$id_check."-".$value->namapasien;?>">
                            <i class="fa fa-volume-up"></i>
                          </button>
                        </a>
                        <a href="#">
                          <button data-toggle="tooltip" id="UMU2-<?php echo $value->no_urutkunjungan?>" data-placement="top" title="" data-original-title="Panggil Poli Umum 2" type="button" class="btn default-color periksa btn-sm panggilan_pasien hilang-UMU-<?php echo $id_check ?>" antrian="<?php echo $_SESSION['poli']."2-".$value->no_antrian."-".$id_check."-".$value->namapasien;?>">
                            <i class="fa fa-volume-up"></i>
                          </button>
                        </a>
                      <?php }; ?>

                    <?php endif; ?>
                    <a href="<?php echo base_url()."Kunjungan/delete/".$value->no_urutkunjungan; ?>">
                      <button type="button" class="btn btn-danger hapus-kunjungan btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="Hapus Kunjungan">
                        <i class="fa fa-cut"></i>
                      </button>
                    </a>
                    <a href="<?php echo base_url()."Pasien/edit/".$value->pasien_noRM."/".$value->no_urutkunjungan; ?>">
                      <button type="button" class="btn btn-warning hapus-kunjungan btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit Data Pasien">
                        <i class="fa fa-edit"></i>
                      </button>
                    </a>
                    <a href="#">
                      <button type="button" no_kun="<?php echo $value->no_urutkunjungan?>" no_rm="<?php echo $value->noRM?>" class="btn btn-primary ganti-kunjungan btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="Ganti Tujuan Pelayanan Pasien">
                        <i class="fa fa-edit"></i>
                      </button>
                    </a>
                  </td>
                </tr>

                <?php $no++; endforeach; ?>


              </tbody>

            </table>
          </div>
        </div>
        </div>
      <!-- </div> -->
</div>
<script src="https://js.pusher.com/5.1/pusher.min.js"></script>
  <script>

    // Enable pusher logging - don't include this in production
    Pusher.logToConsole = true;

    var pusher = new Pusher('7d98f72380966ec579c6', {
      cluster: 'ap1',
      forceTLS: true
    });

    var channel = pusher.subscribe('ci_pusher3');
    channel.bind('my-event3', function(data) {
      // alert(data.poli);
      $(".hilang-"+data.poli+"-"+data.nokun).hidden();

    });

$(document).ready(function(){

  $(document).on("click",".ganti-kunjungan",function(){
    var no = $(this).attr("no_kun");
    var no_rm = $(this).attr("no_rm");
    $(".ganti_nokun").val(no);
    $(".no_rm").val(no_rm);
    $("#ganti_tupel").modal("toggle");
  })
})
</script>
