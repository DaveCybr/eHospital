
<div class="card">
  <div class="card-body card-block">
    <div class="row form-group">
            <div class="col col-md-3">
              <label for="thnpartus" class=" form-control-label">Tahun Partus</label>
            </div>
            <div class="col-12 col-md-9">
              <input type="number" name="thnpartusdd" id="thnpartus" class="form-control" placeholder="Tahun Partus" value="" >
            </div>
    </div>
    <div class="row form-group">
            <div class="col col-md-3">
              <label for="tempatpartus" class=" form-control-label">Tempat Partus</label>
            </div>
            <div class="col-12 col-md-9">
              <input type="text" name="tempatpartusdd" id="tempatpartus" class="form-control" placeholder="Tempat Partus" value="" >
            </div>
    </div>
    <div class="row form-group">
            <div class="col col-md-3">
              <label for="umur" class=" form-control-label">Umur Hamil</label>
            </div>
            <div class="col-12 col-md-9">
              <input type="number" name="umurdd" id="umurhamil" class="form-control" placeholder="Umur Hamil" value="" >
            </div>
    </div>
    <div class="row form-group">
            <div class="col col-md-3">
              <label for="jenis_persalinan" class=" form-control-label">Jenis Persalinan</label>
            </div>
            <div class="col-12 col-md-9">
              <input type="text" name="jenis_persalinandd" id="jenis_persalinan" class="form-control" placeholder="Jenis Persalinan" value="" >
            </div>
    </div>
    <div class="row form-group">
            <div class="col col-md-3">
              <label for="penolong" class=" form-control-label">Penolong</label>
            </div>
            <div class="col-12 col-md-9">
              <input type="text" name="penolongdd" id="penolong" class="form-control" placeholder="Penolong" value="" >
            </div>
    </div>
    <div class="row form-group">
            <div class="col col-md-3">
              <label for="penyulit" class=" form-control-label">Penyulit</label>
            </div>
            <div class="col-12 col-md-9">
              <input type="text" name="penyulitdd" id="penyulit" class="form-control" placeholder="Penyulit" value="" >
            </div>
    </div>
    <div class="row form-group">
            <div class="col col-md-3">
              <label for="jk" class=" form-control-label">Jenis Kelamin Bayi</label>
            </div>
            <div class="col-12 col-md-9">
              <div class="custom-control custom-radio">
                  <input type="radio" id="jk1" name="jk" class="custom-control-input jk_bayi" value="laki-laki">
                  <label class="custom-control-label" for="jk1">Laki - Laki</label>
              </div>
              <div class="custom-control custom-radio">
                  <input type="radio" id="jk2" name="jk" class="custom-control-input jk_bayi" value="perempuan">
                  <label class="custom-control-label" for="jk2">Perempuan</label>
              </div>
            </div>
    </div>
    <div class="row form-group">
            <div class="col col-md-3">
              <label for="bb" class=" form-control-label">Berat Badan Bayi</label>
            </div>
            <div class="col-12 col-md-9">
              <input type="number" name="bbdd" id="bb_bayi" class="form-control" placeholder="Berat Badan Bayi" value="" >
            </div>
    </div>
    <div class="row form-group">
            <div class="col col-md-3">
              <label for="hm" class=" form-control-label">H / M</label>
            </div>
            <div class="col-12 col-md-9">
              <input type="text" name="hmdd" id="hm_bayi" class="form-control" placeholder="H / M" value="" >
            </div>
    </div>
  </div>
</div>
