
<?php echo form_open('Usulan/delete');?>

<div class="row">
  <div class="col-12">
    <div class="card card-cascade narrower z-depth-1">
      <div class="view view-cascade gradient-card-header blue-gradient narrower py-2 mx-4 mb-3 d-flex justify-content-between align-items-center">
        <div>
              <button type="button" class="btn btn_hapus btn-outline-white btn-rounded btn-sm px-2" data-toggle="tooltip" data-placement="top" title="" data-original-title="Hapus Data"><i class="fas fa-trash-alt mt-0"></i></button>
              <button type="button" class="btn btn-outline-white btn-rounded btn-sm px-2" data-toggle="tooltip" data-placement="top" title="" data-original-title="Jumlah Item Terpilih"><span id="jumlah_pilih">0</span></button>
            </div>
            <a href="" class="white-text mx-3">Usulan Jumlah Obat Obat</a>

      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table id="myTable" class="table table-hover table-striped table-bordered ">
              <thead>
                  <tr>
                    <th width="10%">
                      <input type="checkbox" class="form-check-input select-all" id="tableMaterialChec">
                      <label class="form-check-label" for="tableMaterialChec"></label>
                    </th>

                      <th style="text-align:right;">Tanggal</th>
                      <th>Supplier</th>
                      <!-- <th>Supplier Disetujui</th> -->
                      <th>Status Usulan</th>
                      <th>Opsi</th>
                  </tr>
              </thead>
              <tbody>
                <?php $no=1; foreach ($perencanaan as $data) {?>
                  <?php $id_check = $data->idperencanaan;
                    $sp = $this->db->where("kode_sup",$data->supplier2)->get("supplier")->row();
                  ?>
                  <tr>
                    <td>
                      <input type="checkbox" class="form-check-input id_checkbox" id="tableMaterialCheck<?php echo $id_check ?>" name="id[]" value="<?php echo $id_check ?>">
                      <label class="form-check-label" for="tableMaterialCheck<?php echo $id_check ?>"></label>
                    </td>
                      <td style="text-align:right;"><?php echo date("d-m-Y",strtotime($data->tanggal))?></td>
                      <td><?php echo @$data->nama?></td>
                      <!-- <td><?php echo @$sp->nama?></td> -->
                      <td><?php if ($data->input_usulan==0): ?>
                        Belum input
                        <?php else: ?>
                          <?php if ($data->status_usulan==0): ?>
                            Menunggu Ditinjau
                            <?php else: ?>
                              Sudah Ditinjau
                          <?php endif; ?>
                      <?php endif; ?></td>
                      <td>
                        <?php if ($data->input_usulan==0): ?>
                          <a class="fitur_open" href="<?php base_url()?>/Usulan/input/<?php echo $data->idperencanaan;?>">
                          <button type="button" class="btn btn-warning btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="Lihat Detail">
                            <i class="fa fa-edit"></i> Usulkan Jumlah Obat
                          </button>

                          </a>
                        <?php else: ?>
                          <?php if ($data->status_usulan==0): ?>

                            <a class="fitur_terbatas" href="<?php base_url()?>/Usulan/persetujuan/<?php echo $data->idpengajuan_obat;?>">
                              <button type="button" class="btn btn-success btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="Lihat Detail">
                                <i class="fa fa-edit"></i> TInjau
                              </button>

                            </a>
                          <?php else: ?>

                            <?php if ($data->status_pesanan==1): ?>
                              <?php if ($data->status_mutasi==0): ?>

                                <a class="fitur_open" href="<?php base_url()?>/Usulan/mutasi_gudang/<?php echo $data->idpengajuan_obat;?>">
                                  <button type="button" class="btn btn-success btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="Lihat Detail">
                                    <i class="fa fa-edit"></i>Mutasi Ke Gudang
                                  </button>

                                </a>
                              <?php else: ?>
                                Sudah di mutasi ke gudang
                              <?php endif; ?>
                              <a target="_blank" class="fitur_open" href="<?php base_url()?>/Usulan/cetak_penerimaan/<?php echo $data->idpengajuan_obat;?>">
                                <button type="button" class="btn btn-primary btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="Cetak Faktur">
                                  <i class="fa fa-print"></i>
                                </button>

                              </a>
                            <?php else: ?>
                              <a class="fitur_terbatas" href="<?php base_url()?>/Usulan/persetujuan/<?php echo $data->idpengajuan_obat;?>">
                                <button type="button" class="btn btn-success btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="Lihat Detail">
                                  <i class="fa fa-edit"></i> Tinjau Ulang
                                </button>

                              </a>
                              <a class="fitur_open" href="<?php base_url()?>/Usulan/terima_barang/<?php echo $data->idpengajuan_obat;?>">
                                <button type="button" class="btn btn-success btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="Lihat Detail">
                                  <i class="fa fa-edit"></i>Penerimaan Barang
                                </button>

                              </a>
                              <a target="_blank" class="fitur_open" href="<?php base_url()?>/Usulan/cetak/<?php echo $data->idpengajuan_obat;?>">
                                <button type="button" class="btn btn-warning btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="Cetak Form Pembelian">
                                  <i class="fa fa-print"></i>
                                </button>

                              </a>

                            <?php endif; ?>

                          <?php endif; ?>
                        <?php endif; ?>

                    </td>
                  </tr>
                <?php
                $no++;
                }?>
              </tbody>
            </table>
        </div>
      </div>
    </div>
  </div>
</div>
<div id="alert"><?php echo $this->Core->Hapus_disable(); ?></div>
<div id="modal"><?php echo $this->Core->Hapus_aktif(); ?></div>
<?php echo form_close();?>
<?php $this->load->view($form_dialog)?>
<script>
$(function(){
  var base_url = '<?php echo base_url()?>';
  function myajax_request(url,data,callback){
    $.ajax({
        type  : 'POST',
        url   : url,
        async : false,
        dataType : 'json',
        data:data,
        success : function(response){
            callback(response);
        }
    })
  }

  $(document).on('click','.detail_nota',function(){
    var data_detail = {
      'no_nota' : $(this).attr('id'),
    };
    myajax_request(base_url+"Perencanaan/get_detail",data_detail,function(res){
      var tes="";
      // alert(res);
      for (var i = 0; i < res.length; i++) {
        tes += "<tr>" +
              "<td>"+res[i].idobat+"</td>" +
              "<td>"+res[i].nama_obat+"</td>" +
              "<td>"+res[i].no_batch+"</td>" +
              "<td>"+res[i].tanggal_expired+"</td>" +
              "<td>Rp."+addCommas(res[i].hrg_beli)+"</td>" +
              "<td>"+res[i].jumlah+"</td>" +
              "<td>"+res[i].diskon+"%</td>" +
              "<td>"+res[i].ppn+"%</td>" +
              "<td>Rp."+addCommas(res[i].total_harga)+"</td>" +
              "</tr>";

      }
      $("#no_nota").html(res[0].no_nota);
      $("#no_nota_s").html(res[0].no_nota_supplier);
      $("#tgl_transaksi").html(res[0].tanggal_masuk);
      $("#j_tempo").html(res[0].tanggal_jatuh_tempo);
      $("#supplier").html(res[0].nama);
      $(".sts").html(res[0].status);
      $("#t_disk").html(res[0].total_diskon+"%");
      $("#t_ppn").html(res[0].total_ppn+"%");
      $("#t_harga").html("Rp."+addCommas(res[0].total_transaksi));
      $("#bayar_final").html("Rp."+addCommas(res[0].total_bayar));
      $("#bayar").html("Rp."+addCommas(res[0].bayar));
      $("#sisa").html("Rp."+addCommas(res[0].sisa));
      $("#obat").html(tes);
    });
  });
  function addCommas(nStr)
{
  nStr += '';
  x = nStr.split('.');
  x1 = x[0];
  x2 = x.length > 1 ? '.' + x[1] : '';
  var rgx = /(\d+)(\d{3})/;
  while (rgx.test(x1)) {
      x1 = x1.replace(rgx, '$1' + ',' + '$2');
  }
  return x1 + x2;
}
});

</script>
