
<div class="card">
  <div class="card-body card-block">
    <div class="row form-group">
      <div class="col-md-6">
        <div class="row form-group">
                  <div class="col-md-3">
                    <label for="no_nota_supplier" class=" form-control-label">No Nota Supplier</label>
                  </div>
                  <div class="col-md-9">
                      <input type="text" required name="no_nota_supplier" id="no_nota_supplier" class="form-control" placeholder="xxxxxxxxx" value="<?php echo @$pembelian_obat['no_nota_supplier'];?>">
                  </div>
        </div>
        <div class="row form-group">
                <div class="col-md-3">
                  <label for="supplier" class=" form-control-label">Supplier</label>
                </div>
                <div class="col-md-6">
                  <input type="text" id="nama_sup" class="form-control" value="<?php echo $usulan->nama?>" placeholder="Nama Supplier" readonly required>
                  <input type="text" name="supplier" id="supplier" value="<?php echo $usulan->kode_sup?>"class="form-control" hidden required>
                </div>

        </div>
      </div>
        <div class="col-md-6">
          <div class="row form-group">
                  <div class="col-md-3">
                    <label for="tanggal_masuk" class=" form-control-label">Tanggal Masuk</label>
                  </div>
                  <div class="col-md-9">
                      <input type="date" required name="tanggal_masuk" id="tanggal_masuk" class="tanggal_new2 form-control" value="<?php echo date("d-m-Y") ?>" required>
                  </div>
          </div>

          <div class="row form-group">
                  <div class="col-md-3">
                    <label for="jatuh_tempo" class=" form-control-label">Jatuh Tempo</label>
                  </div>
                  <div class="col-md-9">
                      <input type="date" required name="jatuh_tempo" id="jatuh_tempo" class="tanggal_new form-control" value="<?php echo @$pembelian_obat['jatuh_tempo'] ?>" required>
                  </div>
          </div>
      </div>
    </div>
  </div>
</div>
<div class="card">
  <div class="card-body card-block">
    <div class="row form-group">

      <div class="col-md-12" style="margin-top:20px;">

          <div class="table-responsive">
              <table id="list_pembelian_obat" class="table editable-table table-bordered table-striped m-b-0">
                <thead>
                  <tr>
                    <th >Nama Obat</th>

                    <th style="min-width:200px;">Expired Date</th>
                    <th >Satuan</th>
                    <th>Jumlah Pesanan</th>
                    <th style="min-width:200px;">Harga Beli</th>
                    <th style="min-width:200px;">Jumlah</th>
                    <th style="min-width:200px;">Diskon (%)</th>
                    <th style="min-width:200px;">PPN (%)</th>
                    <th>Total Harga</th>
                  </tr>
                </thead>
                <tbody id="obat">
                  <?php foreach ($detail_obat as $value): ?>
                    <?php $kode = $value->obat_idobat?>


                    <tr>
                      <td><input hidden value='<?php echo $kode?>' name='id_obat[]'><input hidden value='' name='satuan[]' id='satuan<?php echo $kode?>'><?php echo $value->nama_obat?></td>
                      <td><input type='date' name='ed[]' class='form-control'>
                        <input hidden value='<?php echo $value->iddetail_pengajuan?>' name='id_detail[]'>
                      </td>
                      <td><input type="hidden" name="satuan[]" value="<?php echo $value->satuan_kecil?>"><?php echo $value->satuan_kecil?></td>
                      <td><?php echo $value->jumlah_disetujui?></td>
                      <td><input type='text' min='0' id='hrg<?php echo $kode?>' kode='<?php echo $kode?>' name='harga_beli[]' class='money<?php echo $kode?> form-control beli' value="<?php echo $value->harga_beli?>" onkeydown='return alphaOnly(event);'></td>
                      <td><input type='number' disetujui="<?php echo $value->jumlah_disetujui?>" min='0' id='jml<?php echo $kode?>' kode='<?php echo $kode?>' class='form-control jml_beli' name='jumlah[]' value='1'></td>
                      <td><input class='diskon_obat form-control diskon' id='diskon<?php echo $kode?>' kode='<?php echo $kode?>' value='0'  min='0' type='number' name='diskon[]'></td>
                      <td><input class='ppn_obat form-control' type='number' min='0' kode='<?php echo $kode?>' id='ppn<?php echo $kode?>' value='0' name='ppn[]'></td>
                      <td style='text-align:right;'><input class='ttl_harga_obat ttl_harga<?php echo $kode?>' type='hidden' value='<?php echo $value->harga_beli?>' name='ttl_harga[]'><span id='label_ttl_<?php echo $kode?>'><?php echo "Rp.".number_format($value->harga_beli)?></span></td>
                    </tr>
                  <?php endforeach; ?>
                  <input type="hidden" id="tot_harga" value="" name="tot_harga">
                  <input type="hidden" class="bayar_final" value="" name="bayar_final">
                  <input type="hidden" class="sisa" value="" name="sisa">
                </tbody>
                <tfoot>
                    <tr>
                        <th colspan="6"><strong>TOTAL</strong></th>
                        <!-- <th id="t_disk">Rp.0</th>
                        <th id="t_ppn">Rp.0</th>
                        <th id="t_harga">Rp.0</th> -->
                        <th><input type="number" id="tot_diskon" min="0" value="0" name="tot_diskon" class="form-control"></th>
                        <th><input type="number" id="tot_ppn" min="0" value="0" name="tot_ppn" class="form-control"></th>
                        <th id="t_harga" style="text-align:right;">Rp.0</th>
                        <!-- <th></th> -->
                    </tr>
                    <tr>
                        <th colspan="6"><strong>TOTAL YANG HARUS DIBAYAR (TOTAL HARGA+PPN %) - DISKON %</strong></th>
                        <th colspan="2" id="bayar_final" style="text-align:right;">Rp.0</th>
                        <th></th>
                    </tr>
                    <tr>
                        <th colspan="6"><strong>BAYAR</strong></th>
                        <th colspan="2" id="bayar"><input style="direction: rtl;" type="text" min="0" class="money bayar form-control" value="" name="bayar" required></th>
                        <th></th>
                    </tr>
                    <tr>
                        <th colspan="6"><strong>SISA</strong></th>
                        <th colspan="2" id="sisa" style="text-align:right;">Rp.0</th>
                        <th></th>
                    </tr>
                </tfoot>
              </table>
          </div>
          <!-- END DATA TABLE-->
        </div>
    </div>
  </div>
</div>
	<script type="text/javascript" src="<?php echo base_url();?>desain/dist/simple.money.format.js"></script>
	<script type="text/javascript">
		$('.money').simpleMoneyFormat();
	</script>
  <script src="<?php echo base_url();?>desain/assets/custom/usulanobat.js"></script>
<script>


$(function(){
  var base_url = '<?php echo base_url()?>';
  function myajax_request(url,data,callback){
    $.ajax({
        type  : 'POST',
        url   : url,
        async : false,
        dataType : 'json',
        data:data,
        success : function(response){
            callback(response);
        }
    })
  }
  $('.tanggal_new').pickadate({
  // min: new Date(2015,3,20),
  format: 'dd-mm-yyyy',
  formatSubmit: 'yyyy-mm-dd',
  min: true
})
$('.tanggal_new2').pickadate({
// min: new Date(2015,3,20),
format: 'dd-mm-yyyy',
formatSubmit: 'yyyy-mm-dd',
max: true
})

  $(document).on('click','.hapus_detail',function(){
    var data_detail = {
      'id' : $(this).attr('id'),
    };
    var index_row = $(this);
    myajax_request(base_url+"PembelianObat/hapus_detail",data_detail,function(res){
      if(res.success){
        deleteRowLab(index_row);
      }
    });
  });

  $(document).on("click","#simpan",function(){
    var th = $(this);
    var status = 0;
    $(".jml_beli").each(function(){
      var disetujui = parseInt($(this).attr("disetujui"));
      var jumlah = parseInt($(this).val());
      // alert(disetujui);
      if(jumlah > disetujui){
        status = 1;
        alert("Jumlah terima melebihi jumlah disetujui");
        th.focus();
        return false;
      }
    })
    if (status==0) {
      $("#form_simpan").submit();
      // alert("sukses");
    }
  })

  $(document).on("change","#search_obat",function(){
    var data = {
     'id_obat' : $("#search_obat option:selected").val()
    };
    myajax_request(base_url+"PembelianObat/get_satuan",data,function(respone){
     var mark = ""
     if (respone.length>0) {
       for(var i=0;i<respone.length;i++){
         mark += '<option value ="'+respone[i].harga_satuan+'" nama_satuan="'+respone[i].label+'">'+respone[i].satuan+'</option>'
       }
       $("#hrg_bl").val(respone[0].harga_satuan);
     }else{
       mark += '<option value="">-- Satuan Obat --</option>';
       $("#hrg_bl").val(0);
     }
     $("#satuan_obat").html(mark);

    });
  });
});
</script>
