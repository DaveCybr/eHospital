<div class="table-responsive">
  <table id="table_sajian" class="table table-striped table-bordered ">
  <thead>
      <tr>
          <th width="5%">No</th>
          <th>Tanggal Disajikan</th>
          <th>Jam</th>
          <th>Opsi</th>
      </tr>
  </thead>
  <tbody id="sajian">

  </tbody>
  <tfoot>
    <tr>
      <td colspan="3"></td>
      <td ></td>
    </tr>
    <tr>
      <td colspan="3">Disajikan Hari Ini</td>
      <td class="hari_ini"></td>
    </tr>
    <tr>
      <td colspan="3">Total Disajikan</td>
      <td class="total_sajian"></td>
    </tr>

  </tfoot>
  </table>
</div>
