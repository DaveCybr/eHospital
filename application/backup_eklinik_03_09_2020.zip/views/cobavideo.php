<!DOCTYPE html>
<html>
<body>

<h1>The video autoplay attribute</h1>

<video width="320" height="240" controls autoplay>
  <source src="http://eklinik.klinikdokterku.com/desain/video/corona2.mp4" type="video/mp4">
  Your browser does not support the video tag.
</video>

</body>
</html>
