<div class="col-md-6">
  <div class="form-group ">
        <h3>Jadwal Operasi</h3>
         <select class="mdb-select colorful-select dropdown-info sm-form" name="nama_dokter" id="nama_dokter" >
           <?php foreach ($pegawai as $value): ?>
             <option value="<?php echo $value->NIK ?>"><?php echo $value->nama ?></option>
           <?php endforeach; ?>
         </select>
  </div>
</div>

<div class="form-group m-t-40 row">
    <label for="example-text-input" class="col-2 col-form-label">Tanggal</label>
    <div class="col-10">
        <input class="form-control" type="date" name="tanggal" id="jam" value="<?php echo @$JadwalOperasi['tanggal'] ?>">
    </div>
</div>

<div class="form-group m-t-40 row">
    <label for="example-text-input" class="col-2 col-form-label">Jam</label>
    <div class="col-10">
        <input class="form-control" type="time" name="jam" id="jam" value="<?php echo @$JadwalOperasi['jam'] ?>">
    </div>
</div>
