<style>
.form-group{
  margin-bottom: 5px;
}
</style>
<div class="card">
<div class="card-body card-block">

  <div class="row form-group">
        <div class="col col-md-3">
          <label for="text-input" class=" form-control-label">Tanggal</label>
        </div>
        <div class="col-12 col-md-9">
            <input type="date" name="tanggal" id="nama_kamar" class="form-control" placeholder="" >
        </div>
  </div>
  <div class="row form-group">
        <div class="col col-md-3">
          <label for="text-input" class=" form-control-label">pengumuman</label>
        </div>
        <div class="col-12 col-md-9">
          <textarea name="pengumuman" class="form-control"></textarea>
        </div>
  </div>



</div>
</div>
