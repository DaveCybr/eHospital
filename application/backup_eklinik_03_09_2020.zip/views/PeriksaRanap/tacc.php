
<?php echo form_open(base_url()."Periksa/rujuk_eksternal",array("id"=>"form_rujukan"));?>
<div class="row pt-12">
  <!-- <h2>Rujuk lanjut</h2> -->

    <div class="class col-md-3">

      <div class="form-group animated flipIn">
        <div class="custom-control custom-radio">
          <input type="radio" id="tanpa" name="tacc" value="0" class="custom-control-input pilih_tacc"  required checked>

          <label class="custom-control-label" for="tanpa">Tanpa TACC</label>
        </div>
      </div>

      <div class="form-group animated flipIn">
        <div class="custom-control custom-radio">
          <input type="radio" id="time" name="tacc" value="1" class="custom-control-input pilih_tacc"  required>

          <label class="custom-control-label" for="time">Time</label>
        </div>
      </div>
      <div class="form-group animated flipIn">
        <div class="custom-control custom-radio">
          <input type="radio" id="age" name="tacc" value="2" class="custom-control-input pilih_tacc"  required>

          <label class="custom-control-label" for="age">Age</label>
        </div>
      </div>
      <div class="form-group animated flipIn">
        <div class="custom-control custom-radio">
          <input type="radio" id="complication" name="tacc" value="3" class="custom-control-input pilih_tacc"  required>

          <label class="custom-control-label" for="complication">Complication</label>
        </div>

      </div>

      <div class="form-group animated flipIn">
        <div class="custom-control custom-radio">
          <input type="radio" id="comorbidity" name="tacc" value="4" class="custom-control-input pilih_tacc"  required>

          <label class="custom-control-label" for="comorbidity">Comorbidity</label>
        </div>

      </div>
  </div>
  <div class="col-md-9" id="a_tacc">
    <div class="form-group animated flipIn">
      <label for="exampleInputuname">Alasan TACC</label>
      <div class="input-group mb-3">
        <!-- <div class="input-group-prepend">
        <span class="input-group-text" id="basic-addon1"><i class="ti-instagram"></i></span>
      </div> -->
      <!-- <select id="dropdown_tacc" name="alasan_tacc" class="mdb-select mdb-lg form-control colorful-select dropdown-info">
        <option value="null">Tanpa TACC</option>
      </select> -->
      <textarea class="form-control" id="dropdown_tacc" name="alasan_tacc"></textarea>
    </div>
  </div>
  </div>

  <div class="col-md-12">
    <div class="form-group animated flipIn">
      <button type="submit" class="btn btn-sm btn-success btn_rujuk">Rujuk Sekarang</button>
    </div>
  </div>
  <input type="hidden" id="kodeppk" name="kodeppk" value="">
  <input type="hidden" id="jenis" name="jenis" value="">
  <input type="hidden" id="sub" name="sub" value="">
  <input type="hidden" id="kode_rujuk" name="kode_rujuk" value="">
  <input type="hidden" id="nomor_kunjungan" name="nomor_kunjungan" value="">
  <input type="hidden" id="est_rujuk" name="est_rujuk" value="">
  <input type="hidden" id="sarana_input" name="sarana" value="">
  <input type="hidden" id="catatan" name="catatan" value="">
  <input type="hidden" id="nmppk" name="nmppk" value="">
  <input type="hidden" id="jadwal" name="jadwal" value="">
</div>
<?php echo form_close()?>
<script>
  $(document).ready(function(){

      $(document).on("click",".pilih_tacc",function(){
        var tacc = $(this).val();
        // alert($("#diag").val());
        html ="<option value='null'>Dignosa</option>";
        if (tacc==0) {
          // alert(0);
          $("#dropdown_tacc").html(html);
        }else if (tacc==3) {
          // alert(3);
          $("#dropdown_tacc").html(html);
        }else if(tacc==2){

        }else{

        }
      })
  })

  $(document).on("click",".btn_rujuk",function(){
    // alert("dajdka");
    $("#form_rujukan").submit();
  })

</script>
