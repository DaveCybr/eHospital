<div class="row pt-12">
  <!-- <h2>Rujuk lanjut</h2> -->
  <div class="class col-md-3">

    <div class="form-group animated flipIn">
      <label for="exampleInputuname">tanggal rencana berkunjung</label>
      <div class="input-group">
        <div class="input-group-prepend">
        <span class="input-group-text" id="basic-addon1"><i class="ti-calendar"></i></span>
      </div>
      <input type="date" id="tanggal_rujuk" height="500px" class="form-control" value="<?php echo date("Y-m-d")?>" min="<?php echo date("Y-m-d")?>" name="tanggal" width="100%">
    </div>
  </div>
</div>
<div class="class col-md-3">
  <div class="form-group animated flipIn">
    <label for="exampleInputuname">Fasilitas Kesehatan rujuk lanjut</label>
    <div class="input-group mb-3">
      <!-- <div class="input-group-prepend">
      <span class="input-group-text" id="basic-addon1"><i class="ti-instagram"></i></span>
    </div> -->
    <select id="jenis_rujuk" name="jenis_rujuk" class="mdb-select mdb-lg form-control colorful-select dropdown-info">
      <option value="khusus">khusus</option>
      <option value="spesialis">spesialis</option>
    </select>
  </div>
</div>
</div>
<div class="class col-md-3" id="form-spesialis">

  <div class="form-group animated flipIn" >
    <label for="exampleInputuname" id="label-spesialis">Spesialis</label>
    <div class="input-group">
      <!-- <div class="input-group-prepend">
      <span class="input-group-text" id="basic-addon1"><i class="ti-instagram"></i></span>
    </div> -->
    <select id="spesialis" name="spesialis" class="mdb-select form-control colorful-select dropdown-info">
      <?php if (!empty($rujuk)): ?>

        <?php foreach ($rujuk->response->list as $value): ?>
          <option value="<?php echo $value->kdKhusus?>"><?php echo $value->nmKhusus?></option>
        <?php endforeach; ?>
      <?php else: ?>
        <option>Koneksi Pcare Bermasalah</option>

      <?php endif; ?>
    </select>
  </div>
</div>
</div>
<div class="class col-md-3" id="form-sub">

  <div class="form-group animated flipIn" >
    <label for="exampleInputuname" id="label-sub">Sub Spesialis</label>
    <div class="input-group">
      <!-- <div class="input-group-prepend">
      <span class="input-group-text" id="basic-addon1"><i class="ti-instagram"></i></span>
    </div> -->
    <select id="sub_spesialis" name="sub_spesialis" class="form-control mdb-select colorful-select dropdown-info">

    </select>
  </div>
</div>
</div>

<div class="class col-md-3" id="form-sarana">
  <div class="form-group animated flipIn" >
    <label for="exampleInputuname" id="label_sarana">Sarana</label>
    <div class="input-group mb-3">
      <!-- <div class="input-group-prepend">
      <span class="input-group-text" id="basic-addon1"><i class="ti-instagram"></i></span>
    </div> -->
    <select id="sarana" name="sarana" class="form-control mdb-select colorful-select dropdown-info">

    </select>
  </div>
</div>

</div>
<div class="class col-md-3" id="form-sarana2">

  <div class="form-group animated flipIn" >
    <label for="exampleInputuname" id="label_sarana2">Sarana</label>
    <div class="input-group mb-3">
      <!-- <div class="input-group-prepend">
      <span class="input-group-text" id="basic-addon1"><i class="ti-instagram"></i></span>
    </div> -->
    <select id="sarana2" name="sarana2" class="form-control mdb-select colorful-select dropdown-info">
      <option value="0">Pilih Sarana</option>
      <?php if (!empty($sarana)): ?>

        <?php foreach ($sarana->response->list as $value): ?>
          <option value="<?php echo $value->kdSarana?>"><?php echo $value->nmSarana?></option>
        <?php endforeach; ?>
      <?php else: ?>
        <option>Koneksi Pcare Bermasalah</option>

      <?php endif; ?>
    </select>
  </div>
</div>

</div>
<div class="class col-md-3" id="form-catatan">


  <div class="form-group animated flipIn" >
    <label for="exampleInputuname">Catatan</label>
    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" id="basic-addon1"><i class="ti-notepad"></i></span>
      </div>
      <textarea class="form-control" id="ctt"></textarea>
    </div>
  </div>


</div>
<div class="class col-md-3">
  <div class="form-group animated flipIn" >
    <label for="exampleInputuname">Opsi</label>
    <div class="input-group mb-3">


      <button type="button" class="btn btn-default" id="cari_rujukan">cari rujukan</button>
    </div>
  </div>
</div>
<div class="col-md-12">

  <h2>Daftar Faskes Rujukan</h2>
  <div class="table-reseponsive">
    <table class="table table-striped" id="tablerujuk">
      <thead>
        <tr>
          <th>NO</th>
          <th>Faskes</th>
          <th>Kelas</th>
          <th>Kantor Cabang</th>
          <th>Alamat</th>
          <th>Telp</th>
          <th>Jarak</th>
          <th>Total Rujukan</th>
          <th>kapasistas</th>
          <th>pilih</th>

        </tr>
      </thead>
      <tbody id="daftar_faskes">
      </tbody>
    </table>
  </div>



</div>

</div>

<input type="hidden" id="diag" value='<?php echo '<option value="'.$tacc["kodeicdx"].' - '.$tacc["nama_penyakit"].'">'.$tacc['kodeicdx'].' - '.$tacc["nama_penyakit"].'</option>';?>'>
<script>
var base_url = '<?php echo base_url()?>';
var time = ["< 3 Hari", ">= 3 - 7 Hari", ">= 7 Hari"];
var bulan = ["< 1 Bulan", ">= 1 Bulan s/d < 12 Bulan", ">= 1 Tahun s/d < 5 Tahun",">= 5 Tahun s/d < 12 Tahun", ">= 12 Tahun s/d < 55 Tahun", ">= 55 Tahun"];

function myajax_request(url,data,callback){
  $.ajax({
    type  : 'POST',
    url   : url,
    async : false,
    dataType : 'json',
    beforeSend : function(){
      $("#cari_rujukan").html('<i class="fa fa-spinner fa-spin"></i>');
    },
    data:data,
    success : function(response){
      $("#cari_rujukan").html('Cari Rujukan');
      callback(response);
    }
  })
}

$(document).ready(function(){


  $("#form-sub").hide();
  $("#form-sarana").hide();
  $("#form-sarana2").hide();
  $("#label-spesialis").text("Kategori");
  var data_detail = {
    'no_nota' : "dadad",
  };

  $(document).on("click","#cari_rujukan",function(){
    var jenis = $("#jenis_rujuk option:selected").val();
    var tgl = $("#tanggal_rujuk").val();
    if (tgl=="") {
      alert("harap isi tanggal");
    }else{
      if (jenis == 'khusus' ) {
        var kode = $("#spesialis option:selected").val();

        // alert(pos.kode);
        if (kode=="THA" || kode=="HEM") {
          var pos = {
            'kode' : kode ,
            'noRM' : $("#norm").val(),
            'tgl'  : tgl,
            'sub'  : $("#sarana option:selected").val(),
          };
          myajax_request(base_url+"PeriksaRanap/get_rujuk_khusus_spesialis",pos,function(res){
            $("#daftar_faskes").html(res.html);


          })
        }else{
          var pos = {
            'kode' : kode ,
            'noRM' : $("#norm").val(),
            'tgl'  : $("#tanggal_rujuk").val()
          };
          myajax_request(base_url+"PeriksaRanap/get_rujuk_khusus",pos,function(res){
            $("#daftar_faskes").html(res.html);
            // $("#tablerujuk").DataTable();
          })
        }
      }else{
        var kode = $("#spesialis option:selected").val();
        var pos = {
          'kode' : kode ,
          'noRM' : $("#norm").val(),
          'tgl'  : $("#tanggal_rujuk").val(),
          'sub'  : $("#sub_spesialis option:selected").val(),
          'sarana' : $("#sarana2 option:selected").val()
        };
        // alert(pos.sarana);
        myajax_request(base_url+"PeriksaRanap/get_rujuk_spesialis",pos,function(res){
          // alert(res.html);
          $("#daftar_faskes").html(res.html);
          // $("#tablerujuk").DataTable();
        })
      }
    }
    $("#tablerujuk").DataTable();

  })

  $(document).on("change","#jenis_rujuk",function(){

    var jenis = $("#jenis_rujuk option:selected").val();
    if (jenis=="spesialis") {

      $("#label-spesialis").text("Spesialis");
      myajax_request(base_url+"PeriksaRanap/get_spesialis",data_detail,function(res){
        // var html = "";
        // for (var i = 0; i < res.length; i++) {
        //   html +="<option value='"+res[i].kdSpesialis+"'>"+res[i].nmSpesialis+"</option>"
        // }
        // alert(html);
        $("#spesialis").html(res.spesialis);
        $("#sub_spesialis").html(res.sub);
        // $("#sarana2").html(res.spesialis);
        $("#label_sarana").html("Sarana");
        $("#form-sub").show();
        $("#form-sarana2").show();

        $("#form-sarana").hide();
        $("#form-catatan").hide();


      })
    }else{
      $("#label-spesialis").text("Kategori");
      myajax_request(base_url+"PeriksaRanap/get_khusus",data_detail,function(res){
        // var html = "";
        // for (var i = 0; i < res.length; i++) {
        //   html +="<option value='"+res[i].kdSpesialis+"'>"+res[i].nmSpesialis+"</option>"
        // }
        // alert(html);
        $("#spesialis").html(res.khusus);
        // $("#label_sarana").html("Sarana");
        $("#form-sub").hide();
        $("#form-sarana2").hide();
        $("#form-sarana").hide();
        $("#form-catatan").show();


      });
    }
  })

  $(document).on("change","#spesialis",function(){

    var jenis = $("#jenis_rujuk option:selected").val();
    if (jenis!="spesialis") {
      // alert("jdhajda");
      var kode = $("#spesialis option:selected").val();
      // alert(kode);
      if (kode=="THA" || kode=="HEM") {
        myajax_request(base_url+"PeriksaRanap/get_spesialis_khusus",data_detail,function(res){
          var html = "";
          for (var i = 0; i < res.length; i++) {
            html +="<option value='"+res[i].kdSubSpesialis+"'>"+res[i].nmSubSpesialis+"</option>"
          }
          // alert(html);
          $("#sarana").html(html);
          $("#label_sarana").html("Spesialis");
          $("#form-catatan").hide();
          $("#form-sarana").show();


        })
      }else{
        $("#form-sarana").hide();
        $("#form-catatan").show();
      }
    }else{
      var kode = $("#spesialis option:selected").val();
      var data_pos = {
        'kode' : kode,
      };
      // alert(data_pos);
      myajax_request(base_url+"PeriksaRanap/get_subspesialis",data_pos,function(res){
        $("#sub_spesialis").html(res.sub);
        // alert(res_sub);
      })
    }
  });

  $(document).on("click",".pilih_rujukan",function(){
    var kodeppk = $(this).attr("ppk");
    var kode = $(this).attr("kode");
    var jenis = $(this).attr("jenis");
    var nokun = $("#nokun").val();
    var sub = $(this).attr("sub");
    var jadwal = $(this).attr("jadwal");
    var nmppk = $(this).attr("nmppk");
    $("#kodeppk").val(kodeppk);
    $("#jenis").val(jenis);
    $("#nomor_kunjungan").val(nokun);
    $("#kode_rujuk").val(kode);
    $("#sub").val(sub);
    $("#sarana_input").val($("#sarana2 option:selected").val());
    $("#catatan").val($("#ctt").text());
    $("#nmppk").val(nmppk);
    $("#jadwal").val(jadwal);
    // alert(data_pos.nokun);
    $("#est_rujuk").val($("#tanggal_rujuk").val());
    $("#tacc").modal("toggle");
  })


})
</script>
