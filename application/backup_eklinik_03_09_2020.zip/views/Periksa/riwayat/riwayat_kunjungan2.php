<div class="col-md-12 col-12 col-xl-12">
  <!-- Card Narrower -->
  <div class="card card-cascade narrower z-depth-1">
    <div class="view view-cascade gradient-card-header purple-gradient narrower py-2 mx-4 mb-3 d-flex justify-content-between align-items-center">
          <h4><a href="" class="white-text mx-3">Riwayat Kunjungan Pasien</a></h4>

    </div>
    <!-- Card content -->
    <div class="card-body">


        <div class="table-responsive table--no-card m-b-40">
          <table id="tabel_riwayat" class="table table-borderless table-striped table-earning">
          <thead>
            <th>#</th>
            <th>Nomor Kunjungan</th>
            <th>Tanggal Kunjungan</th>
            <th>Tujuan Poli</th>
            <th>Keluhan</th>
            <th>Riwayat Dulu</th>
            <th>Riwayat Sekarang</th>
            <th>Temp</th>
            <th>Kesadaran</th>
            <th>Sistole</th>
            <th>Diastole</th>
            <th>Nadi</th>
            <th>RR</th>
            <th>BB</th>
            <th>TB</th>
          </thead>
          <tbody id="tabel_riwayat_kunjungan">
            <?php $data_kunjungan = $this->ModelPeriksa->get_riwayat_kunjungan(@$pasien['noRM']); ?>
            <?php $no=1;foreach ($data_kunjungan as $data): ?>
                <tr class="data_kunjungan" id="<?php echo $data->idperiksa?>">
                  <td><?php echo $no++?>
                  <td><?php echo $data->no_urutkunjungan;?></td>
                  <td><?php echo date("d-m-Y",strtotime($data->tgl));?></td>
                  <td><?php echo $data->tujuan_pelayanan;?></td>
                  <td><?php echo $data->keluhan;?></td>
                  <td><?php echo $data->riwayat_dulu;?></td>
                  <td><?php echo $data->riwayat_skrg;?></td>
                  <td><?php echo $data->otemp;?></td>
                  <td><?php echo $data->osadar;?></td>
                  <td><?php echo $data->osiastole;?></td>
                  <td><?php echo $data->odiastole;?></td>
                  <td><?php echo $data->onadi;?></td>
                  <td><?php echo $data->orr;?></td>
                  <td><?php echo $data->obb;?></td>
                  <td><?php echo $data->otb;?></td>
                </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        </div>

        <h3>Diagnosa</h3>
        <div class="table-responsive table--no-card m-b-40">
          <table id="tabel_riwayat" class="table table-borderless table-striped table-earning">
          <thead>
            <th>#</th>
            <th>Kode Sakit</th>
            <th>Nama Penyakit</th>

          </thead>
          <tbody id="diagnosa_kunjungan">
          </tbody>
        </table>
        </div>

        <h3>Resep</h3>
        <div class="table-responsive table--no-card m-b-40">
          <table class="table table-borderless table-striped table-earning">
          <thead>
            <th>#</th>
            <th>kode resep</th>
            <th>kode obat</th>
            <th>Nama obat</th>
            <th>Jumlah</th>
            <th>Satuan</th>
            <th>Signa</th>
          </thead>
          <tbody id="resep_kunjungan">

          </tbody>
        </table>
        </div>


      </div>

      </div>

    </div>
    <!-- Card Narrower -->

  </div>
</div>
<script>
var base_url = '<?php echo base_url()?>';

function myajax_request2(url,data,callback){
  $.ajax({
    type  : 'POST',
    url   : url,
    async : false,
    dataType : 'json',
    data:data,
    success : function(response){
      callback(response);
    }
  })
}
$(document).ready(function(){
  $("#tabel_riwayat").dataTable();
  $(document).on("click",".data_kunjungan",function(){
    var idperiksa = $(this).attr("id");
    var data_detail = {
      'idperiksa' : idperiksa
    };
    // alert(idperiksa);
    myajax_request2(base_url+"Periksa/get_riwayat",data_detail,function(res){
      // alert(res);
      $("#diagnosa_kunjungan").html(res.diagnosa);
      $("#resep_kunjungan").html(res.resep);

    })
  })
});
</script>
