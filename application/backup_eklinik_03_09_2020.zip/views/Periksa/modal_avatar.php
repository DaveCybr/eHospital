<!--Modal Form Login with Avatar Demo-->
  <div class="modal fade" id="modalLoginAvatarDemo" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
    aria-hidden="true">
    <div class="modal-dialog cascading-modal modal-avatar modal-sm" role="document">
      <!--Content-->
      <div class="modal-content">

        <!--Header-->
        <div class="modal-header">
          <img src="<?php echo base_url()?>desain/opps.jpg" class="rounded-circle img-responsive"
            alt="Avatar photo">
        </div>
        <!--Body-->
        <div class="modal-body text-center mb-1">

          <h3 class="mt-1 mb-2">Opss!!</h3>
          <h5 class="mt-1 mb-2">Lakukan Pemeriksaan Telebih Dahulu Ya</h5>


          <div class="text-center mt-4">
            <button class="btn btn-cyan" data-dismiss="modal">Okay
              <i class="fas fa-sign-in ml-1"></i>
            </button>
          </div>
        </div>

      </div>
      <!--/.Content-->
    </div>
  </div>
  <!--Modal Form Login with Avatar Demo-->
