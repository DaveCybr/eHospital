<style>
  .gigi{
    display: inline-block;width:50px;height:auto;cursor: pointer;background-color:rgba(150, 40, 27, 1);color: white;
  }
</style>
<!-- <div class="row"> -->
<div class="card color-bordered-table info-bordered-table">
  <div class="card-body card-block">
    <div class="col-md-12 col">
        <div class="col col-md-12">
          <?php
            for($i=18;$i>=14;$i--){?>
              <span <?php if (@$periksa['gigi_'.$i]!=null) {
                echo "style='background-color:#01c0c8'";
              }?> tittle="Gigi <?php echo $i;?>" href="#" id="gigi_18" class="gigi" data-toggle="tooltip" data-placement="top" data-original-title="<?php if (@$periksa['gigi_'.$i]!=null) {
                echo $periksa['gigi_'.$i];
              }?>"><span><center><?php echo $i;?></center><img src="<?php echo base_url()?>desain/assets/images/gambar_gigi.PNG"></span></span>
          <?php
            }
          ?>
          <?php
            for($i=13;$i>=11;$i--){?>
              <span <?php if (@$periksa['gigi_'.$i]!=null) {
                echo "style='background-color:#01c0c8'";
              }?> tittle="Gigi <?php echo $i;?>" href="#" id="gigi_18" class="gigi" data-toggle="tooltip" data-placement="top" data-original-title="<?php if (@$periksa['gigi_'.$i]!=null) {
                echo $periksa['gigi_'.$i];
              }?>"><span><center><?php echo $i;?></center><img src="<?php echo base_url()?>desain/assets/images/gambar_gigi_2.PNG"></span></span>
          <?php
            }
          ?>
          <span>|</span>
          <?php
            for($i=21;$i<=23;$i++){?>
              <span <?php if (@$periksa['gigi_'.$i]!=null) {
                echo "style='background-color:#01c0c8'";
              }?> tittle="Gigi <?php echo $i;?>" href="#" id="gigi_18" class="gigi" data-toggle="tooltip" data-placement="top" data-original-title="<?php if (@$periksa['gigi_'.$i]!=null) {
                echo $periksa['gigi_'.$i];
              }?>"><span><center><?php echo $i;?></center><img src="<?php echo base_url()?>desain/assets/images/gambar_gigi_2.PNG"></span></span>
          <?php
            }
          ?>
          <?php
            for($i=24;$i<=28;$i++){?>
              <span <?php if (@$periksa['gigi_'.$i]!=null) {
                echo "style='background-color:#01c0c8'";
              }?> tittle="Gigi <?php echo $i;?>" href="#" id="gigi_18" class="gigi" data-toggle="tooltip" data-placement="top" data-original-title="<?php if (@$periksa['gigi_'.$i]!=null) {
                echo $periksa['gigi_'.$i];
              }?>"><span><center><?php echo $i;?></center><img src="<?php echo base_url()?>desain/assets/images/gambar_gigi.PNG"></span></span>
          <?php
            }
          ?>
          </div>
    </div><br>
    <div class="col col-md-12" style="margin-left:150px;">
      <div class="col-md-12 col">
          <div class="col col-md-2"></div>
          <div class="col col-md-8">
            <?php
              for($i=55;$i>=54;$i--){?>
                <span <?php if (@$periksa['gigi_'.$i]!=null) {
                  echo "style='background-color:#01c0c8'";
                }?> tittle="Gigi <?php echo $i;?>" href="#" id="gigi_18" class="gigi" data-toggle="tooltip" data-placement="top" data-original-title="<?php if (@$periksa['gigi_'.$i]!=null) {
                  echo $periksa['gigi_'.$i];
                }?>"><span><center><?php echo $i;?></center><img src="<?php echo base_url()?>desain/assets/images/gambar_gigi.PNG"></span></span>
            <?php
              }
            ?>
            <?php
              for($i=53;$i>=51;$i--){?>
                <span <?php if (@$periksa['gigi_'.$i]!=null) {
                  echo "style='background-color:#01c0c8'";
                }?> tittle="Gigi <?php echo $i;?>" href="#" id="gigi_18" class="gigi" data-toggle="tooltip" data-placement="top" data-original-title="<?php if (@$periksa['gigi_'.$i]!=null) {
                  echo $periksa['gigi_'.$i];
                }?>"><span><center><?php echo $i;?></center><img src="<?php echo base_url()?>desain/assets/images/gambar_gigi_2.PNG"></span></span>
            <?php
              }
            ?>
            <span>|</span>
            <?php
              for($i=61;$i<=63;$i++){?>
                <span <?php if (@$periksa['gigi_'.$i]!=null) {
                  echo "style='background-color:#01c0c8'";
                }?> tittle="Gigi <?php echo $i;?>" href="#" id="gigi_18" class="gigi" data-toggle="tooltip" data-placement="top" data-original-title="<?php if (@$periksa['gigi_'.$i]!=null) {
                  echo $periksa['gigi_'.$i];
                }?>"><span><center><?php echo $i;?></center><img src="<?php echo base_url()?>desain/assets/images/gambar_gigi_2.PNG"></span></span>
            <?php
              }
            ?>
            <?php
              for($i=64;$i<=65;$i++){?>
                <span <?php if (@$periksa['gigi_'.$i]!=null) {
                  echo "style='background-color:#01c0c8'";
                }?> tittle="Gigi <?php echo $i;?>" href="#" id="gigi_18" class="gigi" data-toggle="tooltip" data-placement="top" data-original-title="<?php if (@$periksa['gigi_'.$i]!=null) {
                  echo $periksa['gigi_'.$i];
                }?>"><span><center><?php echo $i;?></center><img src="<?php echo base_url()?>desain/assets/images/gambar_gigi.PNG"></span></span>
            <?php
              }
            ?>
          </div>
          <div class="col-md-2 col"></div>
      </div><br>
      <div class="col-md-12 col">
          <div class="col col-md-2"></div>
          <div class="col col-md-8">
            <?php
              for($i=85;$i>=84;$i--){?>
                <span <?php if (@$periksa['gigi_'.$i]!=null) {
                  echo "style='background-color:#01c0c8'";
                }?> tittle="Gigi <?php echo $i;?>" href="#" id="gigi_18" class="gigi" data-toggle="tooltip" data-placement="top" data-original-title="<?php if (@$periksa['gigi_'.$i]!=null) {
                  echo $periksa['gigi_'.$i];
                }?>"><span><img src="<?php echo base_url()?>desain/assets/images/gambar_gigi.PNG"><center><?php echo $i;?></center></span></span>
            <?php
              }
            ?>
            <?php
              for($i=83;$i>=81;$i--){?>
                <span <?php if (@$periksa['gigi_'.$i]!=null) {
                  echo "style='background-color:#01c0c8'";
                }?> tittle="Gigi <?php echo $i;?>" href="#" id="gigi_18" class="gigi" data-toggle="tooltip" data-placement="top" data-original-title="<?php if (@$periksa['gigi_'.$i]!=null) {
                  echo $periksa['gigi_'.$i];
                }?>"><span><img src="<?php echo base_url()?>desain/assets/images/gambar_gigi_2.PNG"><center><?php echo $i;?></center></span></span>
            <?php
              }
            ?>
            <span>|</span>
            <?php
              for($i=71;$i<=73;$i++){?>
                <span <?php if (@$periksa['gigi_'.$i]!=null) {
                  echo "style='background-color:#01c0c8'";
                }?> tittle="Gigi <?php echo $i;?>" href="#" id="gigi_18" class="gigi" data-toggle="tooltip" data-placement="top" data-original-title="<?php if (@$periksa['gigi_'.$i]!=null) {
                  echo $periksa['gigi_'.$i];
                }?>"><span><img src="<?php echo base_url()?>desain/assets/images/gambar_gigi_2.PNG"><center><?php echo $i;?></center></span></span>
            <?php
              }
            ?>
            <?php
              for($i=74;$i<=75;$i++){?>
                <span <?php if (@$periksa['gigi_'.$i]!=null) {
                  echo "style='background-color:#01c0c8'";
                }?> tittle="Gigi <?php echo $i;?>" href="#" id="gigi_18" class="gigi" data-toggle="tooltip" data-placement="top" data-original-title="<?php if (@$periksa['gigi_'.$i]!=null) {
                  echo $periksa['gigi_'.$i];
                }?>"><span><img src="<?php echo base_url()?>desain/assets/images/gambar_gigi.PNG"><center><?php echo $i;?></center></span></span>
            <?php
              }
            ?>
          </div>
          <div class="col-md-2 col"></div>
      </div><br>
    </div>
    <div class="col-md-12 col">
        <div class="col col-md-12">
          <?php
            for($i=48;$i>=44;$i--){?>
              <span <?php if (@$periksa['gigi_'.$i]!=null) {
                echo "style='background-color:#01c0c8'";
              }?> tittle="Gigi <?php echo $i;?>" href="#" id="gigi_18" class="gigi" data-toggle="tooltip" data-placement="top" data-original-title="<?php if (@$periksa['gigi_'.$i]!=null) {
                echo $periksa['gigi_'.$i];
              }?>"><span><img src="<?php echo base_url()?>desain/assets/images/gambar_gigi.PNG"><center><?php echo $i;?></center></span></span>
          <?php
            }
          ?>
          <?php
            for($i=43;$i>=41;$i--){?>
              <span <?php if (@$periksa['gigi_'.$i]!=null) {
                echo "style='background-color:#01c0c8'";
              }?> tittle="Gigi <?php echo $i;?>" href="#" id="gigi_18" class="gigi" data-toggle="tooltip" data-placement="top" data-original-title="<?php if (@$periksa['gigi_'.$i]!=null) {
                echo $periksa['gigi_'.$i];
              }?>"><span><img src="<?php echo base_url()?>desain/assets/images/gambar_gigi_2.PNG"><center><?php echo $i;?></center></span></span>
          <?php
            }
          ?>
          <span>|</span>
          <?php
            for($i=31;$i<=33;$i++){?>
              <span <?php if (@$periksa['gigi_'.$i]!=null) {
                echo "style='background-color:#01c0c8'";
              }?> tittle="Gigi <?php echo $i;?>" href="#" id="gigi_18" class="gigi" data-toggle="tooltip" data-placement="top" data-original-title="<?php if (@$periksa['gigi_'.$i]!=null) {
                echo $periksa['gigi_'.$i];
              }?>"><span><img src="<?php echo base_url()?>desain/assets/images/gambar_gigi.PNG"><center><?php echo $i;?></center></span></span>
          <?php
            }
          ?>
          <?php
            for($i=34;$i<=38;$i++){?>
              <span <?php if (@$periksa['gigi_'.$i]!=null) {
                echo "style='background-color:#01c0c8'";
              }?> tittle="Gigi <?php echo $i;?>" href="#" id="gigi_18" class="gigi" data-toggle="tooltip" data-placement="top" data-original-title="<?php if (@$periksa['gigi_'.$i]!=null) {
                echo $periksa['gigi_'.$i];
              }?>"><span><img src="<?php echo base_url()?>desain/assets/images/gambar_gigi_2.PNG"><center><?php echo $i;?></center></span></span>
          <?php
            }
          ?>
        </div><br><br>
        <div class="col col-md-12">
            <div style="width:80px;height:10px;background-color:#01c0c8;display:inline-block"></div><span style=""> Gigi Bermasalah</span><br>
            <div style="width:80px;height:10px;background-color:rgba(150, 40, 27, 1);display:inline-block"></div><span style=""> Gigi Tidak Bermasalah</span><br>

        </div>
    </div>
  </div>
</div>
<div class="card color-bordered-table info-bordered-table">
  <div class="card-body card-block">
    <div class="col-md-12 col">
        <div class="col col-md-12">
          <div class="table table-responsive">
            <table class="table table-borderless table-striped table-earning">
            <thead>
              <th>Gigi Bermasalah</th>
              <th>Keterangan</th>
            </thead>
            <tbody id="periksa_gigi">
              <?php
                for ($i=11; $i<=85 ; $i++) {
                  if (@$periksa['gigi_'.$i]!=null) {?>
                    <tr>
                      <td><?php echo "Gigi ".$i;?></td>
                      <td><?php echo @$periksa['gigi_'.$i]?></td>
                    </tr>
                  <?php
                  }
                }
              ?>
            </tbody>
          </table>
        </div><br><br>
          <div class="table table-responsive">
            <table class="table table-borderless table-striped table-earning">
            <thead>
              <th>#</th>
              <th>Keterangan</th>
            </thead>
            <tbody id="periksa_gigi">
                <tr>
                  <td>Occulasi</td>
                  <td><?php if ($periksa['occulasi']!=null) {
                    echo $periksa['occulasi'];
                  }else{ echo "-" ; }?></td>
                </tr>
                <tr>
                  <td>Torus Palatinus</td>
                  <td><?php if ($periksa['torus_palatinus']!=null) {
                    echo $periksa['torus_palatinus'];
                  }else{ echo "-" ; }?></td>
                </tr>
                <tr>
                  <td>Torus Mandibularis</td>
                  <td><?php if ($periksa['torus_mandibularis']!=null) {
                    echo $periksa['torus_mandibularis'];
                  }else{ echo "-" ; }?></td>
                </tr>
                <tr>
                  <td>Palatum</td>
                  <td><?php if ($periksa['palatum']!=null) {
                    echo $periksa['palatum'];
                  }else{ echo "-" ; }?></td>
                </tr>
                <tr>
                  <td>Diastema</td>
                  <td><?php if ($periksa['diastema']!=null) {
                    echo $periksa['diastema'];
                  }else{ echo "-" ; }?></td>
                </tr>
                <tr>
                  <td>Anomali</td>
                  <td><?php if ($periksa['gigi_anomali']!=null) {
                    echo $periksa['gigi_anomali'];
                  }else{ echo "-" ; }?></td>
                </tr>
                <tr>
                  <td>Lain lain</td>
                  <td><?php if ($periksa['lain_lain']!=null) {
                    echo $periksa['lain_lain'];
                  }else{ echo "-" ; }?></td>
                </tr>
                <tr>
                  <td>Photo</td>
                  <td><?php if ($periksa['photo']!=null) {
                    echo $periksa['photo']." (".$periksa['jenis_photo'].")";
                  }else{ echo "-" ; }?></td>
                </tr>
                <tr>
                  <td>Rontgen</td>
                  <td><?php if ($periksa['rontgen']!=null) {
                    echo $periksa['rontgen']." (".$periksa['jenis_rontgen'].")";
                  }else{ echo "-" ; }?></td>
                </tr>
            </tbody>
          </table>
          </div>
        </div>
      </div>
    </div>
  </div>
<!-- </div> -->
