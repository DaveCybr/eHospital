<div class="table-responsive">
  <img width="100%" id="img" height="100%" src="">
</div>
