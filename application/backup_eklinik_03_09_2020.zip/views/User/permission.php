fo
<select id='pre-selected-options' multiple='multiple'>
    <option value='elem_1'>elem 1</option>
    <option value='elem_2'>elem 2</option>
    <option value='elem_3'>elem 3</option>
    <option value='elem_4' selected>elem 4</option>
    <option value='elem_5' selected>elem 5</option>
    <option value="elem_6">elem 6</option>
    <option value="elem_7">elem 7</option>
    <option value="elem_8">elem 8</option>
    <option value="elem_9">elem 9</option>
    <option value="elem_10">elem 10</option>
    <option value="elem_11">elem 11</option>
    <option value="elem_12">elem 12</option>
    <option value="elem_13">elem 13</option>
    <option value="elem_14">elem 14</option>
    <option value="elem_15">elem 15</option>
    <option value="elem_16">elem 16</option>
    <option value="elem_17">elem 17</option>
    <option value="elem_18">elem 18</option>
    <option value="elem_19">elem 19</option>
    <option value="elem_20">elem 20</option>
</select>
