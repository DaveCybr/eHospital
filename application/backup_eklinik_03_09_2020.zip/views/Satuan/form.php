
<div class="card">
  <div class="card-body card-block">
    <div class="row form-group">
            <div class="col col-md-3">
              <label for="nama_satuan" class=" form-control-label">Nama Satuan</label>
            </div>
            <div class="col-12 col-md-9">
                <input type="text" name="nama_satuan" id="nama_satuan" class="form-control" placeholder="nama satuan" value="<?php echo @$satuan['nama_satuan']; ?>" required>
            </div>
    </div>
  </div>
  
</div>
