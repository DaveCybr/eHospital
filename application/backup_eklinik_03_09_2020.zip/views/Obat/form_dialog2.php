<div class="modal fade" id="batchmodal" tabindex="-1" role="dialog" aria-labelledby="scrollmodalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="scrollmodalLabel">DAFTAR BATCH</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
      </div>
      <div class="modal-body">
        <div class="card">
          <div class="card-body card-block">
            <div class="table-responsive">
              <table id="myTable" class="table table-striped table-bordered">
              <thead>
                  <tr>
                      <th>ID/No Barcode</th>
                      <th>No Batch</th>
                      <th>Exxpired Date</th>
                      <th>Stok</th>
                  </tr>
              </thead>
              <tbody id="daftar_batch">

              </tbody>

                </table>
            </div>
          </div>
        </div>
      </div>
  </div>
  </div>
</div>
